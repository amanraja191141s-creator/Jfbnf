/* SA Calculator offline-first localization layer. Stable English source strings are
   translated in-place; formulas, currency/ISO codes, user data and editable values stay intact. */
(function () {
  'use strict';
  const rows = {
    'Settings':['सेटिंग्स','ترتیبات','Ajustes','Paramètres','Einstellungen','الإعدادات','设置'],
    'Help':['सहायता','مدد','Ayuda','Aide','Hilfe','مساعدة','帮助'],
    'FAVORITES':['पसंदीदा','پسندیدہ','FAVORITOS','FAVORIS','FAVORITEN','المفضلة','收藏夹'],
    'TOOLS & CALCULATORS':['टूल और कैलकुलेटर','ٹولز اور کیلکولیٹر','HERRAMIENTAS Y CALCULADORAS','OUTILS ET CALCULATRICES','TOOLS & RECHNER','الأدوات والآلات الحاسبة','工具和计算器'],
    'Choose a workspace to get started':['शुरू करने के लिए कार्यक्षेत्र चुनें','شروع کرنے کے لیے ورک اسپیس منتخب کریں','Elige un espacio de trabajo para comenzar','Choisissez un espace de travail pour commencer','Wählen Sie einen Arbeitsbereich','اختر مساحة عمل للبدء','选择工作区以开始'],
    'Calculator':['कैलकुलेटर','کیلکولیٹر','Calculadora','Calculatrice','Rechner','آلة حاسبة','计算器'],
    'Currencies':['मुद्राएँ','کرنسیاں','Divisas','Devises','Währungen','العملات','货币'],
    'Units':['इकाइयाँ','اکائیاں','Unidades','Unités','Einheiten','الوحدات','单位'],
    'Discount':['छूट','رعایت','Descuento','Réduction','Rabatt','الخصم','折扣'],
    'Percent':['प्रतिशत','فیصد','Porcentaje','Pourcentage','Prozent','النسبة المئوية','百分比'],
    'Sales Tax':['बिक्री कर','سیلز ٹیکس','Impuesto sobre ventas','Taxe de vente','Umsatzsteuer','ضريبة المبيعات','销售税'],
    'Body Metrics':['शरीर के माप','جسمانی پیمائش','Medidas corporales','Mesures corporelles','Körpermaße','قياسات الجسم','身体指标'],
    'Date':['तिथि','تاریخ','Fecha','Date','Datum','التاريخ','日期'],
    'Fuel Cost':['ईंधन लागत','ایندھن کی لاگت','Costo del combustible','Coût du carburant','Kraftstoffkosten','تكلفة الوقود','燃油成本'],
    'Fuel Efficiency':['ईंधन दक्षता','ایندھن کی بچت','Eficiencia de combustible','Efficacité énergétique','Kraftstoffeffizienz','كفاءة الوقود','燃油效率'],
    'Grade Average':['ग्रेड औसत','اوسط گریڈ','Promedio de notas','Moyenne des notes','Notendurchschnitt','متوسط الدرجات','平均成绩'],
    'Number Base':['संख्या आधार','نمبر بیس','Base numérica','Base numérique','Zahlensystem','أساس العدد','数字进制'],
    'Loan / EMI':['ऋण / EMI','قرض / EMI','Préstamo / EMI','Prêt / EMI','Kredit / Rate','قرض / قسط','贷款 / 分期'],
    'Savings':['बचत','بچت','Ahorros','Épargne','Ersparnisse','المدخرات','储蓄'],
    'Tip':['टिप','ٹپ','Propina','Pourboire','Trinkgeld','إكرامية','小费'],
    'Unit Price':['इकाई मूल्य','فی یونٹ قیمت','Precio unitario','Prix unitaire','Stückpreis','سعر الوحدة','单位价格'],
    'World Time':['विश्व समय','عالمی وقت','Hora mundial','Heure mondiale','Weltzeit','التوقيت العالمي','世界时间'],
    'History':['इतिहास','سابقہ ریکارڈ','Historial','Historique','Verlauf','السجل','历史记录'],
    'Your recent calculations':['आपकी हाल की गणनाएँ','آپ کے حالیہ حسابات','Tus cálculos recientes','Vos calculs récents','Ihre letzten Berechnungen','حساباتك الأخيرة','最近的计算'],
    'No calculations yet':['अभी कोई गणना नहीं','ابھی کوئی حساب نہیں','Aún no hay cálculos','Aucun calcul pour le moment','Noch keine Berechnungen','لا توجد حسابات بعد','尚无计算记录'],
    'Clear History':['इतिहास मिटाएँ','سابقہ ریکارڈ صاف کریں','Borrar historial','Effacer l’historique','Verlauf löschen','مسح السجل','清除历史记录'],
    'Exchange rates':['विनिमय दरें','شرح تبادلہ','Tipos de cambio','Taux de change','Wechselkurse','أسعار الصرف','汇率'],
    'Refresh':['रीफ्रेश करें','تازہ کریں','Actualizar','Actualiser','Aktualisieren','تحديث','刷新'],
    'From Currency':['मूल मुद्रा','اصل کرنسی','Moneda de origen','Devise source','Ausgangswährung','العملة المصدر','原货币'],
    'To Currency':['लक्ष्य मुद्रा','مطلوبہ کرنسی','Moneda de destino','Devise cible','Zielwährung','العملة المستهدفة','目标货币'],
    'Connecting to exchange-rate providers…':['विनिमय दर प्रदाताओं से जुड़ रहा है…','شرح تبادلہ فراہم کنندگان سے رابطہ ہو رہا ہے…','Conectando con proveedores de tipos de cambio…','Connexion aux fournisseurs de taux de change…','Verbindung zu Wechselkursanbietern…','جارٍ الاتصال بمزودي أسعار الصرف…','正在连接汇率服务…'],
    'Category':['श्रेणी','قسم','Categoría','Catégorie','Kategorie','الفئة','类别'],
    'Length':['लंबाई','لمبائی','Longitud','Longueur','Länge','الطول','长度'],
    'Mass / Weight':['द्रव्यमान / वजन','کمیت / وزن','Masa / peso','Masse / poids','Masse / Gewicht','الكتلة / الوزن','质量 / 重量'],
    'Area':['क्षेत्रफल','رقبہ','Área','Surface','Fläche','المساحة','面积'],
    'Volume':['आयतन','حجم','Volumen','Volume','Volumen','الحجم','体积'],
    'Time':['समय','وقت','Tiempo','Temps','Zeit','الوقت','时间'],
    'Temperature':['तापमान','درجہ حرارت','Temperatura','Température','Temperatur','درجة الحرارة','温度'],
    'Energy':['ऊर्जा','توانائی','Energía','Énergie','Energie','الطاقة','能量'],
    'Power':['शक्ति','طاقت','Potencia','Puissance','Leistung','القدرة','功率'],
    'Pressure':['दबाव','دباؤ','Presión','Pression','Druck','الضغط','压力'],
    'Speed':['गति','رفتار','Velocidad','Vitesse','Geschwindigkeit','السرعة','速度'],
    'Data Size':['डेटा आकार','ڈیٹا سائز','Tamaño de datos','Taille des données','Datengröße','حجم البيانات','数据大小'],
    'Appearance':['दिखावट','ظاہری شکل','Apariencia','Apparence','Darstellung','المظهر','外观'],
    'THEME & COLORS':['थीम और रंग','تھیم اور رنگ','TEMA Y COLORES','THÈME ET COULEURS','DESIGN & FARBEN','السمة والألوان','主题和颜色'],
    'CALCULATOR SETTINGS':['कैलकुलेटर सेटिंग्स','کیلکولیٹر کی ترتیبات','AJUSTES DE CALCULADORA','PARAMÈTRES DE CALCULATRICE','RECHNER-EINSTELLUNGEN','إعدادات الآلة الحاسبة','计算器设置'],
    'DECIMAL & NUMBER FORMAT':['दशमलव और संख्या प्रारूप','اعشاریہ اور نمبر فارمیٹ','DECIMALES Y FORMATO NUMÉRICO','DÉCIMALES ET FORMAT DES NOMBRES','DEZIMAL- UND ZAHLENFORMAT','تنسيق الأرقام والكسور','小数和数字格式'],
    'LANGUAGE':['भाषा','زبان','IDIOMA','LANGUE','SPRACHE','اللغة','语言'],
    'Navigation Language':['ऐप की भाषा','ایپ کی زبان','Idioma de la aplicación','Langue de l’application','App-Sprache','لغة التطبيق','应用语言'],
    'Changes calculator names and navigation labels; tool instructions remain in English.':['ऐप के सभी उपलब्ध लेबल और निर्देशों की भाषा बदलें।','ایپ کے دستیاب تمام لیبل اور ہدایات کی زبان تبدیل کریں۔','Cambia el idioma de las etiquetas e instrucciones disponibles de la aplicación.','Modifie la langue des libellés et instructions disponibles de l’application.','Ändert die Sprache der verfügbaren App-Beschriftungen und Anleitungen.','يغيّر لغة التسميات والتعليمات المتاحة في التطبيق.','更改应用中可用标签和说明的语言。'],
    'STARTUP PREFERENCES':['स्टार्टअप प्राथमिकताएँ','آغاز کی ترجیحات','PREFERENCIAS DE INICIO','PRÉFÉRENCES DE DÉMARRAGE','STARTOPTIONEN','تفضيلات بدء التشغيل','启动偏好设置'],
    'Default Launch Screen':['डिफ़ॉल्ट शुरुआती स्क्रीन','ابتدائی اسکرین','Pantalla de inicio predeterminada','Écran de démarrage par défaut','Standard-Startbildschirm','شاشة التشغيل الافتراضية','默认启动页面'],
    'Standard Calculator':['सामान्य कैलकुलेटर','معیاری کیلکولیٹر','Calculadora estándar','Calculatrice standard','Standardrechner','الآلة الحاسبة القياسية','标准计算器'],
    'Currency Converter':['मुद्रा परिवर्तक','کرنسی کنورٹر','Conversor de divisas','Convertisseur de devises','Währungsrechner','محول العملات','货币转换器'],
    'Unit Converter':['इकाई परिवर्तक','یونٹ کنورٹر','Conversor de unidades','Convertisseur d’unités','Einheitenumrechner','محول الوحدات','单位转换器'],
    'Done':['हो गया','مکمل','Listo','Terminé','Fertig','تم','完成'],
    'CANCEL':['रद्द करें','منسوخ','CANCELAR','ANNULER','ABBRECHEN','إلغاء','取消'],
    'SAVE':['सहेजें','محفوظ کریں','GUARDAR','ENREGISTRER','SPEICHERN','حفظ','保存'],
    'Add':['जोड़ें','شامل کریں','Añadir','Ajouter','Hinzufügen','إضافة','添加'],
    'Search':['खोजें','تلاش','Buscar','Rechercher','Suchen','بحث','搜索'],
    'Male':['पुरुष','مرد','Hombre','Homme','Männlich','ذكر','男性'],
    'Female':['महिला','عورت','Mujer','Femme','Weiblich','أنثى','女性'],
    'Calculate BMI and an estimated basal metabolic rate from your measurements. Results are informational estimates, not a medical diagnosis.':['अपने माप से BMI और अनुमानित बेसल मेटाबॉलिक रेट की गणना करें। परिणाम केवल जानकारी के लिए हैं, चिकित्सीय निदान नहीं।','اپنی پیمائش سے BMI اور بنیادی میٹابولک ریٹ کا تخمینہ لگائیں۔ نتائج صرف معلوماتی ہیں، طبی تشخیص نہیں۔','Calcula el IMC y una tasa metabólica basal estimada. Los resultados son informativos y no constituyen un diagnóstico médico.','Calculez l’IMC et le métabolisme basal estimé. Ces résultats sont informatifs et ne constituent pas un diagnostic médical.','Berechnen Sie BMI und geschätzten Grundumsatz. Die Ergebnisse dienen nur zur Information und sind keine medizinische Diagnose.','احسب مؤشر كتلة الجسم ومعدل الأيض الأساسي التقديري. النتائج للمعلومات فقط وليست تشخيصًا طبيًا.','根据测量值计算 BMI 和估算基础代谢率。结果仅供参考，不构成医疗诊断。'],
    'Fullscreen (this session)':['पूर्ण स्क्रीन (इस सत्र में)','فل اسکرین (اس سیشن میں)','Pantalla completa (esta sesión)','Plein écran (cette session)','Vollbild (diese Sitzung)','ملء الشاشة (هذه الجلسة)','全屏（本次会话）'],
    'Display Font Size':['प्रदर्शन फ़ॉन्ट आकार','ڈسپلے فونٹ سائز','Tamaño de fuente','Taille de police','Schriftgröße','حجم خط العرض','显示字体大小'],
    'Compact':['संक्षिप्त','مختصر','Compacto','Mode compact','Kompakt','مضغوط','紧凑'],
    'Standard (Default)':['मानक (डिफ़ॉल्ट)','معیاری (ڈیفالٹ)','Estándar (predeterminado)','Standard (par défaut)','Standard (Standard)','قياسي (افتراضي)','标准（默认）'],
    'Comfortable Large':['आरामदायक बड़ा','آرام دہ بڑا','Grande cómodo','Grand confortable','Komfortabel groß','كبير مريح','舒适大号'],
    'Keep Screen Awake (this session)':['स्क्रीन चालू रखें (इस सत्र में)','اسکرین بیدار رکھیں (اس سیشن میں)','Mantener pantalla activa (esta sesión)','Garder l’écran actif (cette session)','Bildschirm eingeschaltet lassen','إبقاء الشاشة نشطة (هذه الجلسة)','保持屏幕常亮（本次会话）'],
    'Accent Palette':['एक्सेंट रंग पैलेट','نمایاں رنگوں کا مجموعہ','Paleta de acento','Palette d’accentuation','Akzentpalette','لوحة الألوان المميزة','强调色板'],
    'Choose light, dark or follow your device.':['लाइट, डार्क या डिवाइस की थीम चुनें।','روشن، گہرا یا ڈیوائس کی تھیم منتخب کریں۔','Elige claro, oscuro o el tema del dispositivo.','Choisissez clair, sombre ou le thème de votre appareil.','Hell, dunkel oder Geräteeinstellung wählen.','اختر الفاتح أو الداكن أو إعداد الجهاز.','选择浅色、深色或跟随设备。'],
    'Light':['हल्का','روشن','Claro','Clair','Hell','فاتح','浅色'],
    'Dark':['गहरा','گہرا','Oscuro','Sombre','Dunkel','داكن','深色'],
    'Follow System':['सिस्टम के अनुसार','سسٹم کے مطابق','Seguir el sistema','Suivre le système','System folgen','اتباع النظام','跟随系统'],
    'Trigonometric Angle Unit':['त्रिकोणमितीय कोण इकाई','مثلثاتی زاویے کی اکائی','Unidad angular trigonométrica','Unité d’angle trigonométrique','Trigonometrische Winkeleinheit','وحدة الزاوية المثلثية','三角函数角度单位'],
    'Degrees (DEG)':['डिग्री (DEG)','ڈگری (DEG)','Grados (DEG)','Degrés (DEG)','Grad (DEG)','درجات (DEG)','度（DEG）'],
    'Radians (RAD)':['रेडियन (RAD)','ریڈین (RAD)','Radianes (RAD)','Radians (RAD)','Radiant (RAD)','راديان (RAD)','弧度（RAD）'],
    'Instant Calculation Preview':['तत्काल गणना पूर्वावलोकन','فوری حساب کا پیش منظر','Vista previa del cálculo instantáneo','Aperçu du calcul instantané','Sofortige Berechnungsvorschau','معاينة الحساب الفوري','即时计算预览'],
    'Implicit Multiplication':['निहित गुणा','ضمنی ضرب','Multiplicación implícita','Multiplication implicite','Implizite Multiplikation','الضرب الضمني','隐式乘法'],
    'Decimal Places (Precision)':['दशमलव स्थान (सटीकता)','اعشاری مقامات (درستگی)','Decimales (precisión)','Décimales (précision)','Dezimalstellen (Genauigkeit)','المنازل العشرية (الدقة)','小数位数（精度）'],
    'Auto':['स्वचालित','خودکار','Automático','Automatique','Automatisch','تلقائي','自动'],
    'Digit Grouping (Separator)':['अंकों का समूह (विभाजक)','ہندسوں کی گروپنگ (جداکار)','Agrupación de dígitos (separador)','Groupement des chiffres (séparateur)','Zifferngruppierung (Trennzeichen)','تجميع الأرقام (الفاصل)','数字分组（分隔符）'],
    'Trailing Zeros':['अंतिम शून्य','آخری صفر','Ceros finales','Zéros finaux','Nachkommastellen-Nullen','الأصفار النهائية','末尾零'],
    'FAVORITES MANAGEMENT':['पसंदीदा प्रबंधन','پسندیدہ کا انتظام','GESTIÓN DE FAVORITOS','GESTION DES FAVORIS','FAVORITEN VERWALTEN','إدارة المفضلة','收藏管理'],
    'Toggle calculators pinned in drawer Favorites section:':['ड्रॉअर के पसंदीदा अनुभाग में कैलकुलेटर पिन या अनपिन करें:','ڈراؤر کے پسندیدہ حصے میں کیلکولیٹر پن یا اَن پن کریں:','Fija o quita calculadoras de la sección Favoritos:','Épinglez ou désépinglez les calculatrices dans les favoris :','Rechner im Favoritenbereich anheften oder lösen:','ثبّت أو أزل تثبيت الآلات الحاسبة في المفضلة:','在抽屉收藏夹中固定或取消固定计算器：'],
    'Reset Favorites':['पसंदीदा रीसेट करें','پسندیدہ ری سیٹ کریں','Restablecer favoritos','Réinitialiser les favoris','Favoriten zurücksetzen','إعادة ضبط المفضلة','重置收藏夹'],
    'HISTORY SETTINGS':['इतिहास सेटिंग्स','سابقہ ریکارڈ کی ترتیبات','AJUSTES DEL HISTORIAL','PARAMÈTRES DE L’HISTORIQUE','VERLAUFSEINSTELLUNGEN','إعدادات السجل','历史记录设置'],
    'Record Calculations':['गणनाएँ रिकॉर्ड करें','حسابات محفوظ کریں','Registrar cálculos','Enregistrer les calculs','Berechnungen speichern','تسجيل الحسابات','记录计算'],
    'Max History Entries':['इतिहास की अधिकतम प्रविष्टियाँ','سابقہ ریکارڈ کی زیادہ سے زیادہ اندراجات','Máximo de entradas del historial','Nombre maximal d’entrées','Maximale Verlaufseinträge','الحد الأقصى لإدخالات السجل','历史记录最大条数'],
    'CLIPBOARD & COPY':['क्लिपबोर्ड और कॉपी','کلپ بورڈ اور کاپی','PORTAPAPELES Y COPIA','PRESSE-PAPIERS ET COPIE','ZWISCHENABLAGE & KOPIEREN','الحافظة والنسخ','剪贴板和复制'],
    'Auto-Copy Results':['परिणाम स्वतः कॉपी करें','نتائج خودکار کاپی کریں','Copiar resultados automáticamente','Copier les résultats automatiquement','Ergebnisse automatisch kopieren','نسخ النتائج تلقائيًا','自动复制结果'],
    'SOUND & VIBRATION':['ध्वनि और कंपन','آواز اور ارتعاش','SONIDO Y VIBRACIÓN','SON ET VIBRATION','TON & VIBRATION','الصوت والاهتزاز','声音和振动'],
    'Keypad Touch Sound':['कीपैड स्पर्श ध्वनि','کی پیڈ ٹچ آواز','Sonido del teclado','Son du clavier','Tastenton','صوت لوحة المفاتيح','按键音'],
    'Haptic Vibration':['हैप्टिक कंपन','ہیپٹک ارتعاش','Vibración háptica','Retour haptique','Haptisches Feedback','اهتزاز لمسي','触觉振动'],
    'Vibration Intensity':['कंपन तीव्रता','ارتعاش کی شدت','Intensidad de vibración','Intensité de vibration','Vibrationsstärke','شدة الاهتزاز','振动强度'],
    'PRIVACY':['गोपनीयता','رازداری','PRIVACIDAD','CONFIDENTIALITÉ','DATENSCHUTZ','الخصوصية','隐私'],
    'Diagnostics (local only)':['डायग्नोस्टिक्स (केवल स्थानीय)','تشخیص (صرف مقامی)','Diagnóstico (solo local)','Diagnostics (local uniquement)','Diagnose (nur lokal)','التشخيص (محلي فقط)','诊断（仅本地）'],
    'LOCAL CALCULATIONS':['स्थानीय गणनाएँ','مقامی حسابات','CÁLCULOS LOCALES','CALCULS LOCAUX','LOKALE BERECHNUNGEN','الحسابات المحلية','本地计算'],
    'Clear App Data & Cache':['ऐप डेटा और कैश साफ़ करें','ایپ ڈیٹا اور کیش صاف کریں','Borrar datos y caché de la aplicación','Effacer les données et le cache','App-Daten und Cache löschen','مسح بيانات التطبيق وذاكرته المؤقتة','清除应用数据和缓存'],
    'Please enter your data':['कृपया अपना डेटा दर्ज करें','براہِ کرم اپنا ڈیٹا درج کریں','Introduce tus datos','Veuillez saisir vos données','Bitte geben Sie Ihre Daten ein','يرجى إدخال بياناتك','请输入数据'],
    'Initial value':['प्रारंभिक मान','ابتدائی قدر','Valor inicial','Valeur initiale','Anfangswert','القيمة الأولية','初始值'],
    'Final value':['अंतिम मान','حتمی قدر','Valor final','Valeur finale','Endwert','القيمة النهائية','最终值'],
    'Added tax':['जोड़ा गया कर','شامل کردہ ٹیکس','Impuesto añadido','Taxe ajoutée','Hinzugefügte Steuer','الضريبة المضافة','附加税'],
    'Amount saved':['बचाई गई राशि','بچائی گئی رقم','Cantidad ahorrada','Montant économisé','Eingesparter Betrag','المبلغ المُدَّخر','节省金额'],
    'Height (cm)':['ऊँचाई (सेमी)','قد (سینٹی میٹر)','Altura (cm)','Taille (cm)','Größe (cm)','الطول (سم)','身高（厘米）'],
    'Fuel efficiency':['ईंधन दक्षता','ایندھن کی بچت','Eficiencia de combustible','Efficacité énergétique','Kraftstoffeffizienz','كفاءة الوقود','燃油效率'],
    'Monthly payment':['मासिक भुगतान','ماہانہ ادائیگی','Pago mensual','Paiement mensuel','Monatliche Zahlung','القسط الشهري','每月付款'],
    'Total interest':['कुल ब्याज','کل سود','Interés total','Intérêts totaux','Gesamtzinsen','إجمالي الفائدة','总利息'],
    'Monthly amortization schedule':['मासिक ऋण भुगतान तालिका','ماہانہ ادائیگی کا شیڈول','Calendario de amortización mensual','Tableau d’amortissement mensuel','Monatlicher Tilgungsplan','جدول السداد الشهري','每月摊还计划'],
    'Calculate tip before tax':['कर से पहले टिप की गणना करें','ٹیکس سے پہلے ٹِپ کا حساب لگائیں','Calcular propina antes de impuestos','Calculer le pourboire avant taxes','Trinkgeld vor Steuern berechnen','احسب الإكرامية قبل الضريبة','计算税前小费'],
    'Compare up to four products by price per unit.':['प्रति इकाई कीमत के आधार पर अधिकतम चार उत्पादों की तुलना करें।','فی یونٹ قیمت کے لحاظ سے چار مصنوعات تک کا موازنہ کریں۔','Compara hasta cuatro productos por precio unitario.','Comparez jusqu’à quatre produits par prix unitaire.','Vergleichen Sie bis zu vier Produkte nach Stückpreis.','قارن حتى أربعة منتجات حسب سعر الوحدة.','按单位价格比较最多四种商品。'],
    'United States Dollar':['अमेरिकी डॉलर','امریکی ڈالر','Dólar estadounidense','Dollar des États-Unis','US-Dollar','دولار أمريكي','美元'],
    'Indian Rupee':['भारतीय रुपया','بھارتی روپیہ','Rupia india','Roupie indienne','Indische Rupie','روبية هندية','印度卢比'],
    'Last checked: Not yet':['अंतिम जाँच: अभी नहीं','آخری جانچ: ابھی نہیں','Última comprobación: aún no','Dernière vérification : pas encore','Zuletzt geprüft: noch nicht','آخرین بررسی: هنوز انجام نشده','上次检查：尚未检查'],
    'Rates last updated: Not yet':['दरें अंतिम बार अपडेट: अभी नहीं','شرح آخری بار اپ ڈیٹ: ابھی نہیں','Última actualización de tasas: aún no','Dernière mise à jour des taux : pas encore','Kurse zuletzt aktualisiert: noch nicht','آخر تحديث للأسعار: لم يحدث بعد','汇率上次更新：尚未更新'],
    'No matching currencies':['कोई मिलती-जुलती मुद्रा नहीं','کوئی مماثل کرنسی نہیں','No hay monedas coincidentes','Aucune devise correspondante','Keine passenden Währungen','لا توجد عملات مطابقة','没有匹配的货币'],
    'No currencies found':['कोई मुद्रा नहीं मिली','کوئی کرنسی نہیں ملی','No se encontraron monedas','Aucune devise trouvée','Keine Währungen gefunden','لم يتم العثور على عملات','未找到货币'],
    'Accent Highlight Color':['एक्सेंट हाइलाइट रंग','نمایاں رنگ','Color de resaltado','Couleur de surbrillance','Akzentfarbe','لون التمييز','强调高亮颜色'],
    'OLED Pure Black':['OLED शुद्ध काला','OLED خالص سیاہ','Negro puro OLED','Noir pur OLED','OLED-Tiefschwarz','أسود OLED نقي','OLED纯黑'],
    'Restore Previous Values':['पिछले मान बहाल करें','پچھلی قدریں بحال کریں','Restaurar valores anteriores','Restaurer les valeurs précédentes','Vorherige Werte wiederherstellen','استعادة القيم السابقة','恢复先前的值'],
    'Favorites Management':['पसंदीदा प्रबंधन','پسندیدہ انتظام','Gestión de favoritos','Gestion des favoris','Favoritenverwaltung','إدارة المفضلة','收藏管理'],
    '0 Decimals (Integers)':['0 दशमलव (पूर्णांक)','0 اعشاریے (صحیح اعداد)','0 decimales (enteros)','0 décimale (entiers)','0 Dezimalstellen (Ganzzahlen)','0 منازل عشرية (أعداد صحيحة)','0位小数（整数）'],
    'South Asian':['दक्षिण एशियाई','جنوبی ایشیائی','Surasiático','Asie du Sud','Südasiatisch','جنوب آسيوي','南亚'],
    'Resume Last Used Screen':['पिछली उपयोग की गई स्क्रीन फिर खोलें','آخری استعمال شدہ اسکرین دوبارہ کھولیں','Reanudar la última pantalla utilizada','Reprendre le dernier écran utilisé','Zuletzt verwendeten Bildschirm fortsetzen','استئناف آخر شاشة مستخدمة','恢复上次使用的页面'],
    'Maximum 32 digits allowed':['अधिकतम 32 अंक अनुमत हैं','زیادہ سے زیادہ 32 ہندسے درج کیے جا سکتے ہیں','Se permiten 32 dígitos como máximo','32 chiffres maximum autorisés','Maximal 32 Ziffern zulässig','يُسمح بحد أقصى 32 رقمًا','最多允许32位数字'],
    'Value out of range':['मान सीमा से बाहर है','قدر حد سے باہر ہے','Valor fuera de rango','Valeur hors limites','Wert außerhalb des Bereichs','القيمة خارج النطاق','数值超出范围'],
    'Screen unavailable':['स्क्रीन उपलब्ध नहीं है','اسکرین دستیاب نہیں','Pantalla no disponible','Écran indisponible','Bildschirm nicht verfügbar','الشاشة غير متاحة','页面不可用'],
    'Invalid accent color':['अमान्य एक्सेंट रंग','غلط نمایاں رنگ','Color de acento no válido','Couleur d’accent invalide','Ungültige Akzentfarbe','لون تمييز غير صالح','强调色无效'],
    'Cache cleanup completed':['कैश की सफ़ाई पूरी हुई','کیش کی صفائی مکمل ہوگئی','Limpieza de caché completada','Nettoyage du cache terminé','Cache-Bereinigung abgeschlossen','اكتمل تنظيف ذاكرة التخزين المؤقت','缓存清理完成'],
    'Sharing is unavailable':['साझा करना उपलब्ध नहीं है','شیئرنگ دستیاب نہیں','No se puede compartir','Partage indisponible','Teilen nicht verfügbar','المشاركة غير متاحة','无法分享'],
    'Choose a valid city or time zone':['मान्य शहर या समय क्षेत्र चुनें','درست شہر یا ٹائم زون منتخب کریں','Elige una ciudad o zona horaria válida','Choisissez une ville ou un fuseau horaire valide','Wählen Sie eine gültige Stadt oder Zeitzone','اختر مدينة أو منطقة زمنية صالحة','请选择有效的城市或时区'],
    'Clear Unlocked History':['अनलॉक किया गया इतिहास मिटाएँ','غیر مقفل تاریخ صاف کریں','Borrar historial desbloqueado','Effacer l’historique déverrouillé','Entsperrten Verlauf löschen','مسح السجل غير المقفل','清除未锁定的历史记录'],
    'Protected from clear/delete':['मिटाने/हटाने से सुरक्षित','صاف کرنے/حذف کرنے سے محفوظ','Protegido contra borrado','Protégé contre la suppression','Vor Löschen geschützt','محفوظ من المسح/الحذف','已保护，无法清除/删除'],
    'Calculation protected':['गणना सुरक्षित है','حساب محفوظ ہے','Cálculo protegido','Calcul protégé','Berechnung geschützt','الحساب محمي','计算已受保护'],
    'Copied for sharing':['साझा करने के लिए कॉपी किया गया','شیئر کرنے کے لیے کاپی ہوگیا','Copiado para compartir','Copié pour le partage','Zum Teilen kopiert','تم النسخ للمشاركة','已复制以供分享'],
    'No unlocked history items to clear':['मिटाने के लिए कोई अनलॉक इतिहास प्रविष्टि नहीं','صاف کرنے کے لیے کوئی غیر مقفل اندراج نہیں','No hay elementos desbloqueados que borrar','Aucun élément déverrouillé à effacer','Keine entsperrten Einträge zum Löschen','لا توجد عناصر سجل غير مقفلة لمسحها','没有可清除的未锁定历史项目'],
    'All history slots are protected. Unlock an entry or increase the history limit to record more.':['इतिहास के सभी स्थान सुरक्षित हैं। अधिक रिकॉर्ड करने के लिए कोई प्रविष्टि अनलॉक करें या इतिहास सीमा बढ़ाएँ।','تاریخ کے تمام خانے محفوظ ہیں۔ مزید ریکارڈ کرنے کے لیے کوئی اندراج غیر مقفل کریں یا تاریخ کی حد بڑھائیں۔','Todas las posiciones del historial están protegidas. Desbloquea una entrada o aumenta el límite para guardar más.','Tous les emplacements de l’historique sont protégés. Déverrouillez une entrée ou augmentez la limite.','Alle Verlaufseinträge sind geschützt. Entsperren Sie einen Eintrag oder erhöhen Sie das Limit.','جميع خانات السجل محمية. ألغِ قفل إدخال أو زد الحد لتسجيل المزيد.','所有历史记录位置均已保护。请解锁一项或提高历史记录上限。'],
    'Unlocked history cleared; protected items kept':['अनलॉक इतिहास मिटाया गया; सुरक्षित प्रविष्टियाँ रखी गईं','غیر مقفل تاریخ صاف ہوگئی؛ محفوظ اندراجات برقرار','Historial desbloqueado borrado; se conservaron los elementos protegidos','Historique déverrouillé effacé ; éléments protégés conservés','Entsperrter Verlauf gelöscht; geschützte Einträge behalten','تم مسح السجل غير المقفل مع الاحتفاظ بالعناصر المحمية','已清除未锁定历史记录；保留受保护项目'],
    'Copy unavailable':['कॉपी उपलब्ध नहीं है','کاپی دستیاب نہیں','Copiar no disponible','Copie indisponible','Kopieren nicht verfügbar','النسخ غير متاح','无法复制'],
    'All settings restored to defaults':['सभी सेटिंग्स डिफ़ॉल्ट पर बहाल की गईं','تمام ترتیبات ڈیفالٹ پر بحال ہوگئیں','Todos los ajustes se restauraron','Tous les paramètres ont été réinitialisés','Alle Einstellungen wurden zurückgesetzt','تمت استعادة جميع الإعدادات الافتراضية','所有设置已恢复默认值'],
    'Fullscreen is not available in this browser':['इस ब्राउज़र में पूर्ण स्क्रीन उपलब्ध नहीं है','اس براؤزر میں فل اسکرین دستیاب نہیں','La pantalla completa no está disponible en este navegador','Le plein écran n’est pas disponible dans ce navigateur','Vollbild ist in diesem Browser nicht verfügbar','ملء الشاشة غير متاح في هذا المتصفح','此浏览器不支持全屏'],
    'Screen wake lock is not supported in this browser':['इस ब्राउज़र में स्क्रीन वेक लॉक समर्थित नहीं है','اس براؤزر میں اسکرین ویک لاک کی سہولت نہیں','Este navegador no admite el bloqueo de activación','Ce navigateur ne prend pas en charge le verrouillage de veille','Bildschirm-Wachhaltefunktion wird nicht unterstützt','هذا المتصفح لا يدعم قفل إبقاء الشاشة نشطة','此浏览器不支持屏幕唤醒锁定'],
    'Accent color updated':['एक्सेंट रंग अपडेट किया गया','نمایاں رنگ اپ ڈیٹ ہوگیا','Color de acento actualizado','Couleur d’accent mise à jour','Akzentfarbe aktualisiert','تم تحديث لون التمييز','强调色已更新'],
    'Favorites reset to defaults':['पसंदीदा डिफ़ॉल्ट पर रीसेट किए गए','پسندیدہ ڈیفالٹ پر ری سیٹ ہوگئے','Favoritos restablecidos','Favoris réinitialisés','Favoriten zurückgesetzt','تمت إعادة ضبط المفضلة','收藏已重置为默认值'],
    'Key sound enabled':['की ध्वनि चालू की गई','کلید کی آواز فعال ہوگئی','Sonido de teclas activado','Son des touches activé','Tastenton aktiviert','تم تفعيل صوت المفاتيح','按键音已开启'],
    'Key sound muted':['की ध्वनि बंद की गई','کلید کی آواز بند ہوگئی','Sonido de teclas silenciado','Son des touches coupé','Tastenton stummgeschaltet','تم كتم صوت المفاتيح','按键音已静音'],
    'This help panel is unavailable':['यह सहायता पैनल उपलब्ध नहीं है','یہ مدد پینل دستیاب نہیں','Este panel de ayuda no está disponible','Ce panneau d’aide est indisponible','Dieses Hilfe-Panel ist nicht verfügbar','لوحة المساعدة هذه غير متاحة','此帮助面板不可用'],
    'Write a short description before sharing':['साझा करने से पहले संक्षिप्त विवरण लिखें','شیئر کرنے سے پہلے مختصر وضاحت لکھیں','Escribe una breve descripción antes de compartir','Rédigez une courte description avant de partager','Schreiben Sie vor dem Teilen eine kurze Beschreibung','اكتب وصفًا قصيرًا قبل المشاركة','分享前请填写简短说明'],
    'Share sheet opened':['शेयर पैनल खोला गया','شیئر پینل کھل گیا','Se abrió el menú para compartir','Le panneau de partage est ouvert','Teilen-Menü geöffnet','تم فتح لوحة المشاركة','已打开分享面板'],
    'Report copied':['रिपोर्ट कॉपी की गई','رپورٹ کاپی ہوگئی','Informe copiado','Rapport copié','Bericht kopiert','تم نسخ التقرير','报告已复制'],
    'Choose a supported startup screen':['समर्थित शुरुआती स्क्रीन चुनें','معاون ابتدائی اسکرین منتخب کریں','Elige una pantalla de inicio compatible','Choisissez un écran de démarrage pris en charge','Wählen Sie einen unterstützten Startbildschirm','اختر شاشة بدء مدعومة','请选择受支持的启动页面'],
    'Search currency':['मुद्रा खोजें','کرنسی تلاش کریں','Buscar moneda','Rechercher une devise','Währung suchen','ابحث عن عملة','搜索货币'],
    'Search city or time zone':['शहर या समय क्षेत्र खोजें','شہر یا ٹائم زون تلاش کریں','Buscar ciudad o zona horaria','Rechercher une ville ou un fuseau horaire','Stadt oder Zeitzone suchen','ابحث عن مدينة أو منطقة زمنية','搜索城市或时区'],
    'e.g. Birthday':['उदा. जन्मदिन','مثلاً سالگرہ','p. ej., cumpleaños','ex. : anniversaire','z. B. Geburtstag','مثال: عيد الميلاد','例如：生日'],
    'e.g. Monthly budget':['उदा. मासिक बजट','مثلاً ماہانہ بجٹ','p. ej., presupuesto mensual','ex. : budget mensuel','z. B. Monatsbudget','مثال: الميزانية الشهرية','例如：每月预算'],
    'Describe the issue, steps to reproduce, and expected result':['समस्या, उसे दोहराने के चरण और अपेक्षित परिणाम बताएँ','مسئلہ، اسے دہرانے کے مراحل اور متوقع نتیجہ بیان کریں','Describe el problema, los pasos para reproducirlo y el resultado esperado','Décrivez le problème, les étapes pour le reproduire et le résultat attendu','Beschreiben Sie das Problem, die Reproduktionsschritte und das erwartete Ergebnis','صف المشكلة وخطوات إعادة إنتاجها والنتيجة المتوقعة','描述问题、复现步骤和预期结果'],
    'What happened? What did you expect? Which tool or setting was involved?':['क्या हुआ? आपको क्या अपेक्षा थी? कौन-सा टूल या सेटिंग शामिल थी?','کیا ہوا؟ آپ کی کیا توقع تھی؟ کون سا ٹول یا سیٹنگ شامل تھی؟','¿Qué ocurrió? ¿Qué esperabas? ¿Qué herramienta o ajuste estaba implicado?','Que s’est-il passé ? Qu’attendiez-vous ? Quel outil ou réglage était concerné ?','Was ist passiert? Was haben Sie erwartet? Welches Tool oder welche Einstellung war betroffen?','ماذا حدث؟ ماذا كنت تتوقع؟ ما الأداة أو الإعداد المعني؟','发生了什么？您原本期望什么？涉及哪个工具或设置？'],
    'Memory cleared':['मेमोरी साफ़ की गई','میموری صاف ہوگئی','Memoria borrada','Mémoire effacée','Speicher gelöscht','تم مسح الذاكرة','记忆已清除'],
    'Memory is empty':['मेमोरी खाली है','میموری خالی ہے','La memoria está vacía','La mémoire est vide','Der Speicher ist leer','الذاكرة فارغة','记忆为空'],
    'Enter a valid calculation first':['पहले मान्य गणना दर्ज करें','پہلے درست حساب درج کریں','Introduce primero un cálculo válido','Saisissez d’abord un calcul valide','Geben Sie zuerst eine gültige Berechnung ein','أدخل عملية حسابية صالحة أولاً','请先输入有效的计算式'],
    'Memory value is out of range':['मेमोरी मान सीमा से बाहर है','میموری کی قدر حد سے باہر ہے','El valor de memoria está fuera de rango','La valeur mémoire est hors limites','Der Speicherwert liegt außerhalb des Bereichs','قيمة الذاكرة خارج النطاق','记忆值超出范围'],
    'Date could not be saved on this device':['इस डिवाइस पर तारीख सहेजी नहीं जा सकी','اس ڈیوائس پر تاریخ محفوظ نہیں ہو سکی','No se pudo guardar la fecha en este dispositivo','Impossible d’enregistrer la date sur cet appareil','Das Datum konnte auf diesem Gerät nicht gespeichert werden','تعذر حفظ التاريخ على هذا الجهاز','无法在此设备上保存日期'],
    'Enter an event name':['कार्यक्रम का नाम दर्ज करें','ایونٹ کا نام درج کریں','Introduce el nombre del evento','Saisissez le nom de l’événement','Geben Sie einen Ereignisnamen ein','أدخل اسم الحدث','请输入事件名称'],
    'Event name is too long':['कार्यक्रम का नाम बहुत लंबा है','ایونٹ کا نام بہت لمبا ہے','El nombre del evento es demasiado largo','Le nom de l’événement est trop long','Der Ereignisname ist zu lang','اسم الحدث طويل جدًا','事件名称过长'],
    'Choose a valid date':['मान्य तारीख चुनें','درست تاریخ منتخب کریں','Elige una fecha válida','Choisissez une date valide','Wählen Sie ein gültiges Datum','اختر تاريخًا صالحًا','请选择有效日期'],
    'Date deleted':['तारीख हटाई गई','تاریخ حذف ہوگئی','Fecha eliminada','Date supprimée','Datum gelöscht','تم حذف التاريخ','日期已删除'],
    'This city is already on your clock list':['यह शहर आपकी घड़ी सूची में पहले से है','یہ شہر پہلے ہی آپ کی گھڑیوں کی فہرست میں ہے','Esta ciudad ya está en tu lista de relojes','Cette ville figure déjà dans votre liste d’horloges','Diese Stadt ist bereits in Ihrer Uhrenliste','هذه المدينة موجودة بالفعل في قائمة الساعات','此城市已在您的时钟列表中'],
    'You can add up to 20 world clocks':['आप अधिकतम 20 विश्व घड़ियाँ जोड़ सकते हैं','آپ زیادہ سے زیادہ 20 عالمی گھڑیاں شامل کر سکتے ہیں','Puedes añadir hasta 20 relojes mundiales','Vous pouvez ajouter jusqu’à 20 horloges mondiales','Sie können bis zu 20 Weltuhren hinzufügen','يمكنك إضافة ما يصل إلى 20 ساعة عالمية','最多可添加20个世界时钟'],
    'Protected history limit reached. Increase the history limit first.':['सुरक्षित इतिहास की सीमा पूरी हो गई। पहले इतिहास सीमा बढ़ाएँ।','محفوظ تاریخ کی حد پوری ہوگئی۔ پہلے تاریخ کی حد بڑھائیں۔','Se alcanzó el límite del historial protegido. Aumenta primero el límite.','Limite de l’historique protégé atteint. Augmentez d’abord la limite.','Limit für geschützten Verlauf erreicht. Erhöhen Sie zuerst das Limit.','تم بلوغ حد السجل المحمي. زد الحد أولاً.','已达到受保护历史记录上限。请先提高上限。'],
    'Please click here to add':['जोड़ने के लिए यहाँ क्लिक करें','شامل کرنے کے لیے یہاں کلک کریں','Haz clic aquí para añadir','Cliquez ici pour ajouter','Zum Hinzufügen hier klicken','انضافے کے لیے یہاں کلک کریں','点击此处添加'],
    'Today':['आज','آج','Hoy','Aujourd’hui','Heute','اليوم','今天'],
    'days left':['दिन शेष','دن باقی','días restantes','jours restants','Tage übrig','أيام متبقية','天后'],
    'days ago':['दिन पहले','دن پہلے','días atrás','jours auparavant','Tage zuvor','أيام مضت','天前'],
    'Every year':['हर साल','ہر سال','Cada año','Chaque année','Jedes Jahr','كل عام','每年'],
    'Edit':['संपादित करें','ترمیم کریں','Editar','Modifier','Bearbeiten','تعديل','编辑'],
    'Delete':['हटाएँ','حذف کریں','Eliminar','Supprimer','Löschen','حذف','删除'],
    'Maximum {count} decimal digits allowed':['अधिकतम {count} दशमलव अंक अनुमत हैं','زیادہ سے زیادہ {count} اعشاری ہندسے درج کیے جا سکتے ہیں','Se permiten como máximo {count} decimales','{count} décimales maximum autorisées','Maximal {count} Dezimalstellen zulässig','يُسمح بحد أقصى {count} رقمًا عشريًا','最多允许 {count} 位小数'],
    'Maximum {count} digits allowed':['अधिकतम {count} अंक अनुमत हैं','زیادہ سے زیادہ {count} ہندسے درج کیے جا سکتے ہیں','Se permiten {count} dígitos como máximo','{count} chiffres maximum autorisés','Maximal {count} Ziffern zulässig','يُسمح بحد أقصى {count} رقمًا','最多允许 {count} 位数字'],
    'Maximum {count} subjects allowed':['अधिकतम {count} विषय अनुमत हैं','زیادہ سے زیادہ {count} مضامین کی اجازت ہے','Se permiten como máximo {count} asignaturas','{count} matières maximum autorisées','Maximal {count} Fächer zulässig','يُسمح بحد أقصى {count} مادة','最多允许 {count} 个科目'],
    'Font scale set to {value}':['फ़ॉन्ट स्केल {value} पर सेट किया गया','فونٹ اسکیل {value} پر سیٹ ہوگیا','Escala de fuente establecida en {value}','Échelle de police réglée sur {value}','Schriftgröße auf {value} gesetzt','تم ضبط مقياس الخط على {value}','字体缩放已设为 {value}'],
    'Max history set to {value}':['इतिहास सीमा {value} पर सेट की गई','تاریخ کی حد {value} پر سیٹ ہوگئی','Límite del historial establecido en {value}','Limite de l’historique réglée sur {value}','Verlaufslimit auf {value} gesetzt','تم ضبط حد السجل على {value}','历史记录上限已设为 {value}'],
    'Vibration set to {value}':['कंपन {value} पर सेट किया गया','ارتعاش {value} پر سیٹ ہوگیا','Vibración establecida en {value}','Vibration réglée sur {value}','Vibration auf {value} gesetzt','تم ضبط الاهتزاز على {value}','振动已设为 {value}'],
    'Default startup screen: {screen}':['डिफ़ॉल्ट शुरुआती स्क्रीन: {screen}','ڈیفالٹ ابتدائی اسکرین: {screen}','Pantalla de inicio predeterminada: {screen}','Écran de démarrage par défaut : {screen}','Standard-Startbildschirm: {screen}','شاشة بدء التشغيل الافتراضية: {screen}','默认启动页面：{screen}'],
    'Will resume the last calculator screen on launch':['ऐप खुलने पर पिछली कैलकुलेटर स्क्रीन फिर खुलेगी','ایپ کھلنے پر آخری کیلکولیٹر اسکرین دوبارہ کھلے گی','Se reanudará la última pantalla de calculadora al iniciar','Le dernier écran de calculatrice sera repris au lancement','Beim Start wird der zuletzt verwendete Rechnerbildschirm geöffnet','ستُستأنف آخر شاشة آلة حاسبة عند التشغيل','启动时将恢复上次使用的计算器页面'],
    'Value stored in memory':['मान मेमोरी में सहेजा गया','قدر میموری میں محفوظ ہوگئی','Valor guardado en memoria','Valeur enregistrée en mémoire','Wert im Speicher abgelegt','تم تخزين القيمة في الذاكرة','数值已存入记忆'],
    'Memory increased':['मेमोरी मान बढ़ाया गया','میموری کی قدر بڑھا دی گئی','Valor de memoria aumentado','Valeur mémoire augmentée','Speicherwert erhöht','تمت زيادة قيمة الذاكرة','记忆值已增加'],
    'Memory decreased':['मेमोरी मान घटाया गया','میموری کی قدر کم کردی گئی','Valor de memoria reducido','Valeur mémoire diminuée','Speicherwert verringert','تم تقليل قيمة الذاكرة','记忆值已减少'],
    'ABOUT & SUPPORT':['जानकारी और सहायता','معلومات اور معاونت','ACERCA DE Y SOPORTE','À PROPOS ET ASSISTANCE','INFO & SUPPORT','حول التطبيق والدعم','关于和支持']
  };

  // Expanded reviewed UI catalogue: calculator tools, forms, help, settings and status labels.
  Object.assign(rows, {
    "Appearance Mode": ["दिखावट मोड", "ظاہری شکل کا موڈ", "Modo de apariencia", "Mode d’apparence", "Darstellungsmodus", "وضع المظهر", "外观模式"],
    "Add date": ["तारीख जोड़ें", "تاریخ شامل کریں", "Añadir fecha", "Ajouter une date", "Datum hinzufügen", "إضافة تاريخ", "添加日期"],
    "Age": ["आयु", "عمر", "Edad", "Âge", "Alter", "العمر", "年龄"],
    "Amount per person": ["प्रति व्यक्ति राशि", "فی فرد رقم", "Importe por persona", "Montant par personne", "Betrag pro Person", "المبلغ لكل شخص", "人均金额"],
    "Annually": ["वार्षिक", "سالانہ", "Anualmente", "Annuellement", "Jährlich", "سنويًا", "每年"],
    "Balance": ["शेष राशि", "بقایا رقم", "Saldo", "Solde", "Kontostand", "الرصيد", "余额"],
    "Basal metabolic rate (BMR)": ["बेसल मेटाबॉलिक दर (BMR)", "بنیادی میٹابولک شرح (BMR)", "Tasa metabólica basal (TMB)", "Métabolisme de base (MB)", "Grundumsatz (BMR)", "معدل الأيض الأساسي (BMR)", "基础代谢率 (BMR)"],
    "Body mass index (BMI)": ["बॉडी मास इंडेक्स (BMI)", "باڈی ماس انڈیکس (BMI)", "Índice de masa corporal (IMC)", "Indice de masse corporelle (IMC)", "Body-Mass-Index (BMI)", "مؤشر كتلة الجسم (BMI)", "身体质量指数 (BMI)"],
    "Calculation Mode": ["गणना मोड", "حساب کا طریقہ", "Modo de cálculo", "Mode de calcul", "Berechnungsmodus", "وضع الحساب", "计算模式"],
    "Calculation name": ["गणना का नाम", "حساب کا نام", "Nombre del cálculo", "Nom du calcul", "Berechnungsname", "اسم العملية الحسابية", "计算名称"],
    "Check amount": ["जाँच राशि", "چیک کی رقم", "Importe de comprobación", "Montant du chèque", "Prüfbetrag", "مبلغ الشيك", "支票金额"],
    "Choose themes, accent palettes, OLED black, number formatting, angle mode, startup screen, favorites, history retention, clipboard, sound and haptics. Some browser features such as fullscreen and screen wake lock depend on device support.": ["थीम, एक्सेंट रंग, OLED ब्लैक, संख्या प्रारूप, कोण मोड, स्टार्टअप स्क्रीन, पसंदीदा, इतिहास, क्लिपबोर्ड, ध्वनि और कंपन चुनें। कुछ ब्राउज़र सुविधाएँ डिवाइस पर निर्भर करती हैं।", "تھیم، نمایاں رنگ، OLED بلیک، نمبر فارمیٹ، زاویہ موڈ، ابتدائی اسکرین، پسندیدہ، ہسٹری، کلپ بورڈ، آواز اور وائبریشن منتخب کریں۔ کچھ براؤزر خصوصیات ڈیوائس پر منحصر ہیں۔", "Elige temas, colores de acento, negro OLED, formato numérico, modo angular, pantalla inicial, favoritos, historial, portapapeles, sonido y vibración. Algunas funciones dependen del dispositivo.", "Choisissez les thèmes, couleurs d’accentuation, noir OLED, format des nombres, mode angulaire, écran de démarrage, favoris, historique, presse-papiers, sons et vibrations. Certaines fonctions dépendent de l’appareil.", "Wählen Sie Designs, Akzentfarben, OLED-Schwarz, Zahlenformat, Winkelmodus, Startbildschirm, Favoriten, Verlauf, Zwischenablage, Ton und Vibration. Einige Funktionen hängen vom Gerät ab.", "اختر السمات وألوان التمييز والأسود OLED وتنسيق الأرقام ووضع الزوايا وشاشة البدء والمفضلة والسجل والحافظة والصوت والاهتزاز. تعتمد بعض الميزات على الجهاز.", "选择主题、强调色、OLED 黑色、数字格式、角度模式、启动屏幕、收藏、历史记录、剪贴板、声音和触觉反馈。部分功能取决于设备支持。"],
    "Converters": ["परिवर्तक", "کنورٹرز", "Convertidores", "Convertisseurs", "Umrechner", "المحوّلات", "转换器"],
    "Copy report": ["रिपोर्ट कॉपी करें", "رپورٹ کاپی کریں", "Copiar informe", "Copier le rapport", "Bericht kopieren", "نسخ التقرير", "复制报告"],
    "Credits": ["क्रेडिट", "کریڈٹس", "Créditos", "Crédits", "Mitwirkende", "الاعتمادات", "鸣谢"],
    "Currency uses dated reference rates when available and clearly labelled offline estimates otherwise. These are not bank, card or remittance quotes. Unit Converter lets you select a category and source/destination units.": ["मुद्रा परिवर्तक उपलब्ध तारीख वाली संदर्भ दरों का उपयोग करता है; अन्यथा ऑफलाइन अनुमान स्पष्ट रूप से दिखाए जाते हैं। ये बैंक या कार्ड की दरें नहीं हैं। इकाई परिवर्तक में श्रेणी और स्रोत/लक्ष्य इकाई चुनें।", "کرنسی کنورٹر دستیاب ہونے پر تاریخ شدہ حوالہ جاتی شرحیں استعمال کرتا ہے، ورنہ آف لائن تخمینے واضح طور پر دکھاتا ہے۔ یہ بینک یا کارڈ کی شرحیں نہیں ہیں۔ یونٹ کنورٹر میں زمرہ اور ماخذ/منزل اکائی منتخب کریں۔", "El conversor usa tipos de referencia fechados cuando están disponibles y, de lo contrario, estimaciones sin conexión claramente indicadas. No son cotizaciones bancarias. El conversor de unidades permite elegir categoría y unidades.", "Le convertisseur utilise des taux de référence datés lorsqu’ils sont disponibles, sinon des estimations hors ligne clairement signalées. Ce ne sont pas des cours bancaires. Le convertisseur d’unités permet de choisir une catégorie et des unités.", "Der Währungsrechner nutzt datierte Referenzkurse, sofern verfügbar, andernfalls klar gekennzeichnete Offline-Schätzungen. Dies sind keine Bank- oder Kartenkurse. Im Einheitenumrechner wählen Sie Kategorie und Einheiten.", "يستخدم محول العملات أسعارًا مرجعية مؤرخة عند توفرها، وإلا يعرض تقديرات غير متصلة بوضوح. هذه ليست أسعار بنكية أو بطاقات. يتيح محول الوحدات اختيار الفئة والوحدات.", "货币转换器在可用时使用带日期的参考汇率，否则明确标示离线估算值。这些并非银行或银行卡报价。单位转换器可选择类别及源/目标单位。"],
    "Date Calculator": ["तारीख कैलकुलेटर", "تاریخ کیلکولیٹر", "Calculadora de fechas", "Calculateur de dates", "Datumsrechner", "حاسبة التواريخ", "日期计算器"],
    "Deposit amount": ["जमा राशि", "جمع رقم", "Importe del depósito", "Montant du dépôt", "Einzahlungsbetrag", "مبلغ الإيداع", "存款金额"],
    "Discount Calculator": ["छूट कैलकुलेटर", "رعایت کیلکولیٹر", "Calculadora de descuentos", "Calculateur de remise", "Rabattrechner", "حاسبة الخصم", "折扣计算器"],
    "Discount percent": ["छूट प्रतिशत", "رعایت فیصد", "Porcentaje de descuento", "Pourcentage de remise", "Rabatt in Prozent", "نسبة الخصم", "折扣百分比"],
    "Distance (km)": ["दूरी (किमी)", "فاصلہ (کلومیٹر)", "Distancia (km)", "Distance (km)", "Entfernung (km)", "المسافة (كم)", "距离（公里）"],
    "Distance traveled (km)": ["तय की गई दूरी (किमी)", "طے شدہ فاصلہ (کلومیٹر)", "Distancia recorrida (km)", "Distance parcourue (km)", "Gefahrene Strecke (km)", "المسافة المقطوعة (كم)", "行驶距离（公里）"],
    "Enter numbers with the keypad or a physical keyboard. Use the scientific panel for advanced functions and DEG/RAD for angle mode.": ["कीपैड या भौतिक कीबोर्ड से संख्याएँ दर्ज करें। उन्नत फ़ंक्शन के लिए वैज्ञानिक पैनल और कोण मोड के लिए DEG/RAD का उपयोग करें।", "کی پیڈ یا فزیکل کی بورڈ سے نمبر درج کریں۔ جدید فنکشنز کے لیے سائنسی پینل اور زاویہ موڈ کے لیے DEG/RAD استعمال کریں۔", "Introduce números con el teclado en pantalla o físico. Usa el panel científico para funciones avanzadas y DEG/RAD para el modo angular.", "Saisissez les nombres avec le clavier à l’écran ou physique. Utilisez le panneau scientifique pour les fonctions avancées et DEG/RAD pour les angles.", "Geben Sie Zahlen über das Tastenfeld oder eine physische Tastatur ein. Nutzen Sie das Wissenschaftsfenster für erweiterte Funktionen und DEG/RAD für Winkel.", "أدخل الأرقام بلوحة المفاتيح أو لوحة مفاتيح فعلية. استخدم اللوحة العلمية للوظائف المتقدمة وDEG/RAD لوضع الزوايا.", "使用屏幕键盘或实体键盘输入数字。高级功能请使用科学面板，角度模式请使用 DEG/RAD。"],
    "Enter price and quantity to compare": ["输入价格和数量进行比较", "موازنہ کرنے کے لیے قیمت اور مقدار درج کریں", "Introduce el precio y la cantidad para comparar", "Saisissez le prix et la quantité pour comparer", "Preis und Menge zum Vergleichen eingeben", "أدخل السعر والكمية للمقارنة", "输入价格和数量进行比较"],
    "Enter value:": ["मान दर्ज करें:", "قدر درج کریں:", "Introduce el valor:", "Saisissez la valeur :", "Wert eingeben:", "أدخل القيمة:", "输入数值："],
    "Enter your data": ["अपना डेटा दर्ज करें", "اپنا ڈیٹا درج کریں", "Introduce tus datos", "Saisissez vos données", "Geben Sie Ihre Daten ein", "أدخل بياناتك", "输入您的数据"],
    "Equal principal": ["समान मूलधन", "یکساں اصل زر", "Capital constante", "Capital constant", "Gleichbleibender Tilgungsanteil", "أصل دين متساوٍ", "等额本金"],
    "Equal total payment": ["समान कुल भुगतान", "یکساں کل ادائیگی", "Cuota total constante", "Paiement total constant", "Gleichbleibende Gesamtzahlung", "إجمالي دفعة متساوٍ", "等额本息"],
    "Event name": ["कार्यक्रम का नाम", "ایونٹ کا نام", "Nombre del evento", "Nom de l’événement", "Ereignisname", "اسم الحدث", "事件名称"],
    "Exclusive (+ Tax)": ["कर अतिरिक्त (+ कर)", "ٹیکس کے علاوہ (+ ٹیکس)", "Exclusivo (+ impuesto)", "Hors taxe (+ taxe)", "Exklusiv (+ Steuer)", "غير شامل للضريبة (+ ضريبة)", "未含税（另加税）"],
    "Feedback & Bug Report": ["प्रतिक्रिया और बग रिपोर्ट", "رائے اور بگ رپورٹ", "Comentarios e informe de errores", "Commentaires et rapport de bogue", "Feedback und Fehlerbericht", "الملاحظات والإبلاغ عن الأخطاء", "反馈与错误报告"],
    "Final price": ["अंतिम कीमत", "حتمی قیمت", "Precio final", "Prix final", "Endpreis", "السعر النهائي", "最终价格"],
    "Final total": ["अंतिम कुल", "حتمی مجموعہ", "Total final", "Total final", "Endsumme", "الإجمالي النهائي", "最终总额"],
    "Find a city or time zone": ["शहर या समय क्षेत्र खोजें", "شہر یا ٹائم زون تلاش کریں", "Buscar una ciudad o zona horaria", "Rechercher une ville ou un fuseau horaire", "Stadt oder Zeitzone suchen", "ابحث عن مدينة أو منطقة زمنية", "搜索城市或时区"],
    "Fuel Cost Calculator": ["ईंधन लागत कैलकुलेटर", "ایندھن لاگت کیلکولیٹر", "Calculadora del coste de combustible", "Calculateur du coût du carburant", "Kraftstoffkostenrechner", "حاسبة تكلفة الوقود", "燃油费用计算器"],
    "Fuel Efficiency Calculator": ["ईंधन दक्षता कैलकुलेटर", "ایندھن کی کارکردگی کیلکولیٹر", "Calculadora de eficiencia de combustible", "Calculateur d’efficacité énergétique", "Kraftstoffeffizienzrechner", "حاسبة كفاءة الوقود", "燃油效率计算器"],
    "Fuel after refueling (L)": ["ईंधन भरने के बाद (लीटर)", "ایندھن بھرنے کے بعد (لیٹر)", "Combustible después de repostar (L)", "Carburant après ravitaillement (L)", "Kraftstoff nach dem Tanken (L)", "الوقود بعد التزود (لتر)", "加油后燃油量（升）"],
    "Fuel before refueling (L)": ["ईंधन भरने से पहले (लीटर)", "ایندھن بھرنے سے پہلے (لیٹر)", "Combustible antes de repostar (L)", "Carburant avant ravitaillement (L)", "Kraftstoff vor dem Tanken (L)", "الوقود قبل التزود (لتر)", "加油前燃油量（升）"],
    "Fuel consumed": ["खपत हुआ ईंधन", "استعمال شدہ ایندھن", "Combustible consumido", "Carburant consommé", "Verbrauchter Kraftstoff", "الوقود المستهلك", "燃油消耗量"],
    "Fuel efficiency (km/L)": ["ईंधन दक्षता (किमी/लीटर)", "ایندھن کی کارکردگی (کلومیٹر/لیٹر)", "Eficiencia (km/L)", "Efficacité (km/L)", "Kraftstoffeffizienz (km/L)", "كفاءة الوقود (كم/لتر)", "燃油效率（公里/升）"],
    "Fuel price ($ / L)": ["ईंधन कीमत ($ / लीटर)", "ایندھن کی قیمت ($ / لیٹر)", "Precio del combustible ($ / L)", "Prix du carburant ($ / L)", "Kraftstoffpreis ($ / L)", "سعر الوقود ($ / لتر)", "燃油价格（$/升）"],
    "Fuel required": ["आवश्यक ईंधन", "درکار ایندھن", "Combustible necesario", "Carburant nécessaire", "Benötigter Kraftstoff", "الوقود المطلوب", "所需燃油"],
    "Gender": ["लिंग", "جنس", "Sexo", "Genre", "Geschlecht", "الجنس", "性别"],
    "Grade": ["ग्रेड", "درجہ", "Nota", "Note", "Note", "الدرجة", "成绩"],
    "Grade Average Calculator": ["ग्रेड औसत कैलकुलेटर", "اوسط گریڈ کیلکولیٹر", "Calculadora de promedio de notas", "Calculateur de moyenne", "Notendurchschnittsrechner", "حاسبة متوسط الدرجات", "成绩平均值计算器"],
    "Help & User Guide": ["सहायता और उपयोगकर्ता मार्गदर्शिका", "مدد اور صارف رہنما", "Ayuda y guía del usuario", "Aide et guide utilisateur", "Hilfe und Benutzerhandbuch", "المساعدة ودليل المستخدم", "帮助与用户指南"],
    "History records standard calculator expressions/results and supports reuse, copy, share, naming, lock/protect and clearing unlocked entries. Tool-specific form values remain inside their own tools and are not added to this list. Protected entries are retained when the normal history limit is reached.": ["इतिहास में सामान्य गणनाएँ और परिणाम सहेजे जाते हैं। उन्हें दोबारा उपयोग, कॉपी, साझा, नामित, सुरक्षित या हटाया जा सकता है। टूल के फ़ॉर्म मान इस सूची में नहीं जुड़ते। सुरक्षित प्रविष्टियाँ सीमा पूरी होने पर भी रखी जाती हैं।", "ہسٹری میں عام کیلکولیٹر کے اظہار اور نتائج محفوظ ہوتے ہیں۔ انہیں دوبارہ استعمال، کاپی، شیئر، نام، لاک یا حذف کیا جا سکتا ہے۔ ٹول کے مخصوص فارم اس فہرست میں شامل نہیں ہوتے۔ محفوظ اندراجات حد پوری ہونے پر بھی برقرار رہتے ہیں۔", "El historial guarda expresiones y resultados del cálculo estándar y permite reutilizarlos, copiarlos, compartirlos, nombrarlos, protegerlos y borrar los desbloqueados. Los datos de formularios de herramientas no se añaden aquí. Los elementos protegidos se conservan al alcanzar el límite.", "L’historique conserve les expressions et résultats du calculateur standard et permet de les réutiliser, copier, partager, nommer, protéger et supprimer les éléments déverrouillés. Les formulaires des outils restent séparés. Les éléments protégés sont conservés lorsque la limite est atteinte.", "Der Verlauf speichert Standardausdrücke und Ergebnisse und ermöglicht Wiederverwendung, Kopieren, Teilen, Benennen, Schützen und Löschen entsperrter Einträge. Formulardaten der Werkzeuge bleiben getrennt. Geschützte Einträge bleiben auch bei erreichtem Limit erhalten.", "يحفظ السجل تعبيرات ونتائج الآلة الحاسبة القياسية، مع إمكانية إعادة استخدامها ونسخها ومشاركتها وتسميتها وحمايتها وحذف غير المحمي منها. تبقى بيانات نماذج الأدوات منفصلة. وتظل العناصر المحمية محفوظة عند بلوغ الحد.", "历史记录保存标准计算器表达式和结果，并支持重用、复制、分享、命名、锁定保护及清除未锁定项目。工具专用表单数据不会加入此列表。达到普通上限时仍会保留受保护项目。"],
    "Inclusive (- Tax)": ["कर सहित（减税）", "ٹیکس سمیت (ٹیکس منہا)", "Incluido (- impuesto)", "TTC (- taxe)", "Inklusive (- Steuer)", "شامل الضريبة (- الضريبة)", "含税（减去税额）"],
    "Interest frequency": ["ब्याज आवृत्ति", "سود کی مدت", "Frecuencia de interés", "Fréquence des intérêts", "Zinsintervall", "وتيرة الفائدة", "计息频率"],
    "Interest income after tax": ["कर के बाद ब्याज आय", "ٹیکس کے بعد سودی آمدنی", "Ingresos por intereses después de impuestos", "Revenu d’intérêt après impôt", "Zinsertrag nach Steuern", "دخل الفائدة بعد الضريبة", "税后利息收入"],
    "Interest income tax (%)": ["ब्याज आय कर (%)", "سود کی آمدنی پر ٹیکس (%)", "Impuesto sobre intereses (%)", "Impôt sur les intérêts (%)", "Steuer auf Zinserträge (%)", "ضريبة دخل الفائدة (%)", "利息收入税（%）"],
    "Interest rate": ["ब्याज दर", "شرح سود", "Tasa de interés", "Taux d’intérêt", "Zinssatz", "سعر الفائدة", "利率"],
    "Interest rate (%)": ["ब्याज दर (%)", "شرح سود (%)", "Tasa de interés (%)", "Taux d’intérêt (%)", "Zinssatz (%)", "سعر الفائدة (%)", "利率（%）"],
    "Interest-only period": ["केवल ब्याज अवधि", "صرف سود کی مدت", "Periodo de solo intereses", "Période de remboursement des intérêts seuls", "Tilgungsfreie Zinsphase", "فترة الفائدة فقط", "只付利息期限"],
    "Item": ["वस्तु", "آئٹم", "Artículo", "Article", "Artikel", "عنصر", "项目"],
    "Last checked: Not yet · Rates last updated: Not yet": ["अंतिम जाँच: अभी नहीं · दरें अंतिम बार अपडेट: अभी नहीं", "آخری جانچ: ابھی نہیں · شرحیں آخری بار اپ ڈیٹ: ابھی نہیں", "Última comprobación: aún no · Última actualización: aún no", "Dernière vérification : jamais · Dernière mise à jour : jamais", "Zuletzt geprüft: noch nicht · Kurse zuletzt aktualisiert: noch nicht", "آخر تحقق: لم يتم بعد · آخر تحديث للأسعار: لم يتم بعد", "上次检查：尚未检查 · 汇率上次更新：尚未更新"],
    "Loading local reference time…": ["स्थानीय संदर्भ समय लोड हो रहा है…", "مقامی حوالہ وقت لوڈ ہو رہا ہے…", "Cargando la hora de referencia local…", "Chargement de l’heure de référence locale…", "Lokale Referenzzeit wird geladen…", "جارٍ تحميل الوقت المرجعي المحلي…", "正在加载本地参考时间…"],
    "Loan / EMI Calculator": ["ऋण / EMI कैलकुलेटर", "قرض / EMI کیلکولیٹر", "Calculadora de préstamo / cuota", "Calculateur de prêt / mensualité", "Kredit-/Ratenrechner", "حاسبة القرض / القسط", "贷款 / 分期计算器"],
    "Loan period (months)": ["ऋण अवधि (महीने)", "قرض کی مدت (مہینے)", "Plazo del préstamo (meses)", "Durée du prêt (mois)", "Kreditlaufzeit (Monate)", "مدة القرض (أشهر)", "贷款期限（月）"],
    "Loan principal": ["ऋण मूलधन", "قرض کی اصل رقم", "Capital del préstamo", "Capital emprunté", "Kreditbetrag", "أصل القرض", "贷款本金"],
    "Name calculation": ["गणना का नाम रखें", "حساب کو نام دیں", "Nombrar cálculo", "Nommer le calcul", "Berechnung benennen", "تسمية العملية الحسابية", "为计算命名"],
    "Nothing is sent automatically": ["कुछ भी अपने आप नहीं भेजा जाता", "کچھ بھی خودکار طور پر نہیں بھیجا جاتا", "No se envía nada automáticamente", "Rien n’est envoyé automatiquement", "Es wird nichts automatisch gesendet", "لا يتم إرسال أي شيء تلقائيًا", "不会自动发送任何内容"],
    "Number Base Converter": ["संख्या आधार परिवर्तक", "نمبر بیس کنورٹر", "Conversor de bases numéricas", "Convertisseur de bases numériques", "Zahlensystem-Umrechner", "محول أنظمة الأعداد", "进制转换器"],
    "Number of people": ["लोगों की संख्या", "افراد کی تعداد", "Número de personas", "Nombre de personnes", "Anzahl der Personen", "عدد الأشخاص", "人数"],
    "Original price": ["मूल कीमत", "اصل قیمت", "Precio original", "Prix d’origine", "Originalpreis", "السعر الأصلي", "原价"],
    "Other tools": ["अन्य टूल", "دیگر ٹولز", "Otras herramientas", "Autres outils", "Weitere Werkzeuge", "أدوات أخرى", "其他工具"],
    "Payment": ["भुगतान", "ادائیگی", "Pago", "Paiement", "Zahlung", "الدفع", "付款"],
    "Per unit": ["प्रति इकाई", "فی اکائی", "Por unidad", "Par unité", "Pro Einheit", "لكل وحدة", "每单位"],
    "Percent Calculator": ["प्रतिशत कैलकुलेटर", "فیصد کیلکولیٹر", "Calculadora de porcentajes", "Calculateur de pourcentage", "Prozentrechner", "حاسبة النسب المئوية", "百分比计算器"],
    "Percent change": ["प्रतिशत परिवर्तन", "فیصد تبدیلی", "Cambio porcentual", "Variation en pourcentage", "Prozentuale Änderung", "التغير بالنسبة المئوية", "百分比变化"],
    "Price": ["कीमत", "قیمت", "Precio", "Prix", "Preis", "السعر", "价格"],
    "Principal": ["मूलधन", "اصل زر", "Capital", "Capital", "Kapital", "أصل المبلغ", "本金"],
    "Project Status": ["प्रोजेक्ट स्थिति", "پروجیکٹ کی حالت", "Estado del proyecto", "État du projet", "Projektstatus", "حالة المشروع", "项目状态"],
    "Quantity": ["मात्रा", "مقدار", "Cantidad", "Quantité", "Menge", "الكمية", "数量"],
    "Repayment method": ["भुगतान विधि", "ادائیگی کا طریقہ", "Método de amortización", "Méthode de remboursement", "Rückzahlungsmethode", "طريقة السداد", "还款方式"],
    "Repeat every year": ["हर साल दोहराएँ", "ہر سال دہرائیں", "Repetir cada año", "Répéter chaque année", "Jedes Jahr wiederholen", "تكرار كل عام", "每年重复"],
    "Reset All Settings": ["सभी सेटिंग रीसेट करें", "تمام ترتیبات ری سیٹ کریں", "Restablecer todos los ajustes", "Réinitialiser tous les paramètres", "Alle Einstellungen zurücksetzen", "إعادة ضبط جميع الإعدادات", "重置所有设置"],
    "Sales Tax Calculator": ["बिक्री कर कैलकुलेटर", "سیلز ٹیکس کیلکولیٹر", "Calculadora de impuestos sobre ventas", "Calculateur de taxe de vente", "Umsatzsteuerrechner", "حاسبة ضريبة المبيعات", "销售税计算器"],
    "Savings Calculator": ["बचत कैलकुलेटर", "بچت کیلکولیٹر", "Calculadora de ahorros", "Calculateur d’épargne", "Sparrechner", "حاسبة الادخار", "储蓄计算器"],
    "Savings balance": ["बचत शेष", "بچت کا بیلنس", "Saldo de ahorros", "Solde d’épargne", "Sparguthaben", "رصيد المدخرات", "储蓄余额"],
    "Savings period (years)": ["बचत अवधि (वर्ष)", "بچت کی مدت (سال)", "Periodo de ahorro (años)", "Durée d’épargne (années)", "Sparzeitraum (Jahre)", "مدة الادخار (سنوات)", "储蓄期限（年）"],
    "Scientific functions": ["वैज्ञानिक फ़ंक्शन", "سائنسی فنکشنز", "Funciones científicas", "Fonctions scientifiques", "Wissenschaftliche Funktionen", "الدوال العلمية", "科学函数"],
    "Select currency": ["मुद्रा चुनें", "کرنسی منتخب کریں", "Seleccionar moneda", "Sélectionner une devise", "Währung auswählen", "اختر العملة", "选择货币"],
    "Settings and history are stored locally in this browser when storage is available. Clearing app data removes locally saved preferences and records.": ["स्टोरेज उपलब्ध होने पर सेटिंग और इतिहास इसी ब्राउज़र में स्थानीय रूप से सहेजे जाते हैं। ऐप डेटा साफ करने से स्थानीय प्राथमिकताएँ और रिकॉर्ड हट जाते हैं।", "اسٹوریج دستیاب ہونے پر ترتیبات اور ہسٹری اسی براؤزر میں مقامی طور پر محفوظ ہوتی ہیں۔ ایپ ڈیٹا صاف کرنے سے مقامی ترجیحات اور ریکارڈ حذف ہو جاتے ہیں۔", "Los ajustes y el historial se guardan localmente en este navegador cuando hay almacenamiento. Al borrar los datos se eliminan las preferencias y registros locales.", "Les paramètres et l’historique sont stockés localement dans ce navigateur si le stockage est disponible. Effacer les données supprime les préférences et enregistrements locaux.", "Einstellungen und Verlauf werden, sofern Speicher verfügbar ist, lokal in diesem Browser gespeichert. Beim Löschen der App-Daten werden lokale Einstellungen und Einträge entfernt.", "تُحفظ الإعدادات والسجل محليًا في هذا المتصفح عند توفر التخزين. يؤدي مسح بيانات التطبيق إلى حذف التفضيلات والسجلات المحلية.", "如果浏览器支持存储，设置和历史记录会保存在本地。清除应用数据会删除本地偏好设置和记录。"],
    "Simple interest": ["साधारण ब्याज", "سادہ سود", "Interés simple", "Intérêt simple", "Einfache Zinsen", "فائدة بسيطة", "单利"],
    "Skip to calculator workspace": ["कैलकुलेटर कार्यक्षेत्र पर जाएँ", "کیلکولیٹر ورک اسپیس پر جائیں", "Ir al espacio de cálculo", "Aller à l’espace calculatrice", "Zum Rechner-Arbeitsbereich springen", "انتقل إلى مساحة الآلة الحاسبة", "跳转到计算器工作区"],
    "Subject": ["विषय", "مضمون", "Asignatura", "Matière", "Fach", "المادة", "科目"],
    "Tap any base row to edit that base": ["उस आधार को संपादित करने के लिए उसकी पंक्ति टैप करें", "اس بیس میں ترمیم کے لیے اس کی قطار پر ٹیپ کریں", "Toca cualquier fila de base para editarla", "Touchez une ligne de base pour la modifier", "Tippen Sie auf eine Basiszeile, um sie zu bearbeiten", "اضغط على أي صف أساس لتعديله", "点击任意进制行以编辑该进制"],
    "Tap any price or quantity field to open the number pad.": ["नंबर पैड खोलने के लिए किसी कीमत या मात्रा फ़ील्ड पर टैप करें।", "نمبر پیڈ کھولنے کے لیے قیمت یا مقدار کے کسی خانے پر ٹیپ کریں۔", "Toca cualquier campo de precio o cantidad para abrir el teclado numérico.", "Touchez un champ de prix ou de quantité pour ouvrir le pavé numérique.", "Tippen Sie auf ein Preis- oder Mengenfeld, um das Zahlenfeld zu öffnen.", "اضغط على حقل السعر أو الكمية لفتح لوحة الأرقام.", "点击价格或数量字段以打开数字键盘。"],
    "Tax amount": ["कर राशि", "ٹیکس کی رقم", "Importe del impuesto", "Montant de la taxe", "Steuerbetrag", "مبلغ الضريبة", "税额"],
    "Tax amount (optional)": ["कर राशि (वैकल्पिक)", "ٹیکس کی رقم (اختیاری)", "Importe del impuesto (opcional)", "Montant de la taxe (facultatif)", "Steuerbetrag (optional)", "مبلغ الضريبة (اختياري)", "税额（可选）"],
    "Tax rate": ["कर दर", "ٹیکس کی شرح", "Tipo impositivo", "Taux de taxe", "Steuersatz", "معدل الضريبة", "税率"],
    "This clears saved settings, history, memory, saved inputs and browser cache. The app will reload after the cleanup.": ["इससे सहेजी गई सेटिंग, इतिहास, मेमोरी, इनपुट और ब्राउज़र कैश साफ हो जाएँगे। सफाई के बाद ऐप फिर से लोड होगा।", "اس سے محفوظ ترتیبات، ہسٹری، میموری، محفوظ ان پٹس اور براؤزر کیش صاف ہو جائیں گے۔ صفائی کے بعد ایپ دوبارہ لوڈ ہوگی۔", "Esto borra ajustes, historial, memoria, entradas guardadas y caché del navegador. La aplicación se recargará al terminar.", "Cela efface les paramètres, l’historique, la mémoire, les saisies enregistrées et le cache du navigateur. L’application se rechargera ensuite.", "Dadurch werden gespeicherte Einstellungen, Verlauf, Speicher, Eingaben und Browsercache gelöscht. Danach wird die App neu geladen.", "يؤدي هذا إلى مسح الإعدادات والسجل والذاكرة والمدخلات المحفوظة وذاكرة التخزين المؤقت للمتصفح. سيُعاد تحميل التطبيق بعد ذلك.", "这将清除已保存的设置、历史记录、内存、输入内容和浏览器缓存。清理完成后应用将重新加载。"],
    "Times use the selected city’s current time-zone rules, including daylight-saving changes where applicable.": ["समय चुने गए शहर के वर्तमान समय-क्षेत्र नियमों का उपयोग करता है, जहाँ लागू हो वहाँ daylight saving सहित।", "اوقات منتخب شہر کے موجودہ ٹائم زون قوانین استعمال کرتی ہیں، جہاں لاگو ہو وہاں ڈے لائٹ سیونگ سمیت۔", "Las horas usan las reglas actuales de la zona horaria de la ciudad seleccionada, incluidos los cambios de horario de verano cuando corresponda.", "Les heures suivent les règles actuelles du fuseau horaire de la ville choisie, y compris les changements d’heure saisonniers le cas échéant.", "Zeiten verwenden die aktuellen Zeitzonenregeln der gewählten Stadt, einschließlich Sommerzeitänderungen, sofern zutreffend.", "تستخدم الأوقات قواعد المنطقة الزمنية الحالية للمدينة المحددة، بما في ذلك التوقيت الصيفي عند تطبيقه.", "时间采用所选城市当前的时区规则，并在适用时包含夏令时调整。"],
    "Tip Calculator": ["टिप कैलकुलेटर", "ٹپ کیلکولیٹر", "Calculadora de propinas", "Calculateur de pourboire", "Trinkgeldrechner", "حاسبة الإكرامية", "小费计算器"],
    "Tip amount": ["टिप राशि", "ٹپ کی رقم", "Importe de la propina", "Montant du pourboire", "Trinkgeldbetrag", "مبلغ الإكرامية", "小费金额"],
    "Tip percent": ["टिप प्रतिशत", "ٹپ فیصد", "Porcentaje de propina", "Pourcentage du pourboire", "Trinkgeld in Prozent", "نسبة الإكرامية", "小费百分比"],
    "Total credits": ["कुल क्रेडिट", "کل کریڈٹس", "Créditos totales", "Crédits totaux", "Gesamtgutschriften", "إجمالي الأرصدة", "总学分"],
    "Total fuel cost": ["कुल ईंधन लागत", "کل ایندھن لاگت", "Coste total del combustible", "Coût total du carburant", "Gesamte Kraftstoffkosten", "إجمالي تكلفة الوقود", "燃油总成本"],
    "Total payments": ["कुल भुगतान", "کل ادائیگیاں", "Pagos totales", "Paiements totaux", "Gesamtzahlungen", "إجمالي المدفوعات", "总付款额"],
    "Total price": ["कुल कीमत", "کل قیمت", "Precio total", "Prix total", "Gesamtpreis", "السعر الإجمالي", "总价"],
    "Unit Price Calculator": ["इकाई मूल्य कैलकुलेटर", "فی یونٹ قیمت کیلکولیٹر", "Calculadora de precio unitario", "Calculateur de prix unitaire", "Stückpreisrechner", "حاسبة سعر الوحدة", "单价计算器"],
    "Your recent calculations will appear here.": ["आपकी हाल की गणनाएँ यहाँ दिखाई देंगी।", "آپ کے حالیہ حسابات یہاں دکھائی دیں گے۔", "Tus cálculos recientes aparecerán aquí.", "Vos calculs récents apparaîtront ici.", "Ihre letzten Berechnungen erscheinen hier.", "ستظهر حساباتك الأخيرة هنا.", "您最近的计算会显示在这里。"],
    "Your report stays on this device until you choose Copy or Share. The app has no built-in feedback upload endpoint.": ["आपकी रिपोर्ट तब तक इसी डिवाइस पर रहती है जब तक आप कॉपी या शेयर नहीं चुनते। ऐप में फीडबैक अपलोड करने की सुविधा नहीं है।", "آپ کی رپورٹ اسی ڈیوائس پر رہتی ہے جب تک آپ کاپی یا شیئر نہ کریں۔ ایپ میں فیڈبیک اپ لوڈ کرنے کا فیچر نہیں ہے۔", "Tu informe permanece en este dispositivo hasta que elijas copiarlo o compartirlo. La aplicación no tiene un servicio integrado para subir comentarios.", "Votre rapport reste sur cet appareil jusqu’à ce que vous choisissiez de le copier ou de le partager. L’application ne dispose pas d’envoi intégré de commentaires.", "Ihr Bericht bleibt auf diesem Gerät, bis Sie ihn kopieren oder teilen. Die App besitzt keine integrierte Feedback-Upload-Funktion.", "يبقى تقريرك على هذا الجهاز حتى تختار نسخه أو مشاركته. لا يحتوي التطبيق على نقطة مدمجة لرفع الملاحظات.", "报告会保留在此设备上，直到您选择复制或分享。应用没有内置反馈上传接口。"],
    "Language changed": ["भाषा बदल दी गई", "زبان تبدیل کر دی گئی", "Idioma cambiado", "Langue modifiée", "Sprache geändert", "تم تغيير اللغة", "语言已更改"],
    "Last checked: {checked} · Rates last updated: {updated}": ["अंतिम जाँच: {checked} · दरें अपडेट: {updated}", "آخری جانچ: {checked} · شرحیں اپ ڈیٹ: {updated}", "Última comprobación: {checked} · Tipos actualizados: {updated}", "Dernière vérification : {checked} · Taux mis à jour : {updated}", "Zuletzt geprüft: {checked} · Kurse aktualisiert: {updated}", "آخر تحقق: {checked} · آخر تحديث للأسعار: {updated}", "上次检查：{checked} · 汇率更新：{updated}"],
  });

  // Accessible names and screen-reader actions for calculator controls.
  Object.assign(rows, {
    "Accent color": ["एक्सेंट रंग", "نمایاں رنگ", "Color de acento", "Couleur d’accentuation", "Akzentfarbe", "لون التمييز", "强调色"],
    "Add date event": ["तारीख कार्यक्रम जोड़ें", "تاریخ کا واقعہ شامل کریں", "Añadir evento de fecha", "Ajouter un événement daté", "Datumsereignis hinzufügen", "إضافة حدث بتاريخ", "添加日期事件"],
    "Add subject": ["विषय जोड़ें", "مضمون شامل کریں", "Añadir asignatura", "Ajouter une matière", "Fach hinzufügen", "إضافة مادة", "添加科目"],
    "Appearance mode": ["दिखावट मोड", "ظاہری شکل کا موڈ", "Modo de apariencia", "Mode d’apparence", "Darstellungsmodus", "وضع المظهر", "外观模式"],
    "Application font size": ["ऐप फ़ॉन्ट आकार", "ایپ فونٹ سائز", "Tamaño de fuente de la aplicación", "Taille de police de l’application", "App-Schriftgröße", "حجم خط التطبيق", "应用字体大小"],
    "Application language": ["ऐप की भाषा", "ایپ کی زبان", "Idioma de la aplicación", "Langue de l’application", "App-Sprache", "لغة التطبيق", "应用语言"],
    "Backspace": ["बैकस्पेस", "بیک اسپیس", "Retroceso", "Retour arrière", "Rücktaste", "مسح للخلف", "退格"],
    "Calculation expression": ["गणना अभिव्यक्ति", "حساب کا اظہار", "Expresión de cálculo", "Expression de calcul", "Rechenausdruck", "تعبير العملية الحسابية", "计算表达式"],
    "Calculation history": ["गणना इतिहास", "حساب کی ہسٹری", "Historial de cálculos", "Historique des calculs", "Berechnungsverlauf", "سجل العمليات الحسابية", "计算历史记录"],
    "Calculator editing tools": ["कैलकुलेटर संपादन टूल", "کیلکولیٹر ترمیمی ٹولز", "Herramientas de edición de calculadora", "Outils d’édition de la calculatrice", "Rechner-Bearbeitungswerkzeuge", "أدوات تحرير الآلة الحاسبة", "计算器编辑工具"],
    "Calculator memory": ["कैलकुलेटर मेमोरी", "کیلکولیٹر میموری", "Memoria de calculadora", "Mémoire de la calculatrice", "Rechnerspeicher", "ذاكرة الآلة الحاسبة", "计算器存储器"],
    "Calculator tools and memory": ["कैलकुलेटर टूल और मेमोरी", "کیلکولیٹر ٹولز اور میموری", "Herramientas y memoria de calculadora", "Outils et mémoire de la calculatrice", "Rechnerwerkzeuge und Speicher", "أدوات وذاكرة الآلة الحاسبة", "计算器工具和存储器"],
    "Calculator workspace": ["कैलकुलेटर कार्यक्षेत्र", "کیلکولیٹر ورک اسپیس", "Espacio de cálculo", "Espace calculatrice", "Rechner-Arbeitsbereich", "مساحة الآلة الحاسبة", "计算器工作区"],
    "Clear": ["साफ़ करें", "صاف کریں", "Borrar", "Effacer", "Löschen", "مسح", "清除"],
    "Clear cached data": ["कैश डेटा साफ़ करें", "کیش ڈیٹا صاف کریں", "Borrar datos en caché", "Effacer les données en cache", "Cache-Daten löschen", "مسح البيانات المخزنة مؤقتًا", "清除缓存数据"],
    "Close": ["बंद करें", "بند کریں", "Cerrar", "Fermer", "Schließen", "إغلاق", "关闭"],
    "Close calculation history": ["गणना इतिहास बंद करें", "حساب کی ہسٹری بند کریں", "Cerrar historial de cálculos", "Fermer l’historique des calculs", "Berechnungsverlauf schließen", "إغلاق سجل الحسابات", "关闭计算历史记录"],
    "Close currency list": ["मुद्रा सूची बंद करें", "کرنسی فہرست بند کریں", "Cerrar lista de monedas", "Fermer la liste des devises", "Währungsliste schließen", "إغلاق قائمة العملات", "关闭货币列表"],
    "Close feedback": ["प्रतिक्रिया बंद करें", "رائے بند کریں", "Cerrar comentarios", "Fermer les commentaires", "Feedback schließen", "إغلاق الملاحظات", "关闭反馈"],
    "Close help": ["सहायता बंद करें", "مدد بند کریں", "Cerrar ayuda", "Fermer l’aide", "Hilfe schließen", "إغلاق المساعدة", "关闭帮助"],
    "Close navigation drawer": ["नेविगेशन मेनू बंद करें", "نیویگیشن مینو بند کریں", "Cerrar menú de navegación", "Fermer le tiroir de navigation", "Navigationsmenü schließen", "إغلاق قائمة التنقل", "关闭导航抽屉"],
    "Converted amount": ["परिवर्तित राशि", "تبدیل شدہ رقم", "Importe convertido", "Montant converti", "Umgerechneter Betrag", "المبلغ المحوّل", "转换金额"],
    "Copy results automatically": ["परिणाम अपने आप कॉपी करें", "نتائج خودکار طور پر کاپی کریں", "Copiar resultados automáticamente", "Copier automatiquement les résultats", "Ergebnisse automatisch kopieren", "نسخ النتائج تلقائيًا", "自动复制结果"],
    "Cube root (∛)": ["घनमूल (∛)", "مکعب جذر (∛)", "Raíz cúbica (∛)", "Racine cubique (∛)", "Kubikwurzel (∛)", "الجذر التكعيبي (∛)", "立方根（∛）"],
    "Currency rate controls": ["मुद्रा दर नियंत्रण", "کرنسی شرح کے کنٹرول", "Controles de tipos de cambio", "Commandes des taux de change", "Wechselkurs-Steuerung", "عناصر التحكم بأسعار العملات", "汇率控制"],
    "Delete before cursor": ["कर्सर से पहले हटाएँ", "کرسر سے پہلے حذف کریں", "Borrar antes del cursor", "Supprimer avant le curseur", "Vor dem Cursor löschen", "حذف قبل المؤشر", "删除光标前内容"],
    "Edit binary value": ["बाइनरी मान संपादित करें", "بائنری قدر میں ترمیم کریں", "Editar valor binario", "Modifier la valeur binaire", "Binärwert bearbeiten", "تعديل القيمة الثنائية", "编辑二进制值"],
    "Edit decimal value": ["दशमलव मान संपादित करें", "اعشاری قدر میں ترمیم کریں", "Editar valor decimal", "Modifier la valeur décimale", "Dezimalwert bearbeiten", "تعديل القيمة العشرية", "编辑十进制值"],
    "Edit hexadecimal value": ["हेक्साडेसिमल मान संपादित करें", "ہیکسا ڈیسیمل قدر میں ترمیم کریں", "Editar valor hexadecimal", "Modifier la valeur hexadécimale", "Hexadezimalwert bearbeiten", "تعديل القيمة السداسية عشرة", "编辑十六进制值"],
    "Edit octal value": ["ऑक्टल मान संपादित करें", "آکٹل قدر میں ترمیم کریں", "Editar valor octal", "Modifier la valeur octale", "Oktalwert bearbeiten", "تعديل القيمة الثمانية", "编辑八进制值"],
    "Enable OLED true black theme": ["OLED ट्रू ब्लैक थीम चालू करें", "OLED ٹرو بلیک تھیم فعال کریں", "Activar tema negro OLED puro", "Activer le thème noir OLED pur", "OLED-Echt-Schwarz-Design aktivieren", "تفعيل سمة الأسود الحقيقي OLED", "启用 OLED 纯黑主题"],
    "Enable diagnostics": ["डायग्नोस्टिक्स चालू करें", "تشخیصی معلومات فعال کریں", "Activar diagnósticos", "Activer les diagnostics", "Diagnose aktivieren", "تفعيل التشخيص", "启用诊断"],
    "Enable full screen": ["पूर्ण स्क्रीन चालू करें", "فل اسکرین فعال کریں", "Activar pantalla completa", "Activer le plein écran", "Vollbild aktivieren", "تفعيل ملء الشاشة", "启用全屏"],
    "Enable haptic feedback": ["हैप्टिक प्रतिक्रिया चालू करें", "ہپٹک فیڈبیک فعال کریں", "Activar respuesta háptica", "Activer le retour haptique", "Haptisches Feedback aktivieren", "تفعيل الاستجابة اللمسية", "启用触觉反馈"],
    "Enable implicit multiplication": ["निहित गुणा चालू करें", "ضمنی ضرب فعال کریں", "Activar multiplicación implícita", "Activer la multiplication implicite", "Implizite Multiplikation aktivieren", "تفعيل الضرب الضمني", "启用隐式乘法"],
    "Enable key sounds": ["कुंजी ध्वनि चालू करें", "کلید کی آواز فعال کریں", "Activar sonidos de teclas", "Activer les sons des touches", "Tastentöne aktivieren", "تفعيل أصوات المفاتيح", "启用按键音"],
    "Enable live result preview": ["लाइव परिणाम पूर्वावलोकन चालू करें", "لائیو نتیجہ پیش منظر فعال کریں", "Activar vista previa del resultado", "Activer l’aperçu du résultat en direct", "Live-Ergebnisvorschau aktivieren", "تفعيل معاينة النتيجة المباشرة", "启用实时结果预览"],
    "From amount": ["मूल राशि", "اصل رقم", "Importe de origen", "Montant d’origine", "Ausgangsbetrag", "المبلغ الأصلي", "原金额"],
    "From currency": ["मूल मुद्रा", "اصل کرنسی", "Moneda de origen", "Devise source", "Ausgangswährung", "عملة المصدر", "源货币"],
    "Gender for basal metabolic rate": ["बेसल मेटाबॉलिक दर के लिए लिंग", "بنیادی میٹابولک شرح کے لیے جنس", "Sexo para la tasa metabólica basal", "Genre pour le métabolisme de base", "Geschlecht für den Grundumsatz", "الجنس لحساب معدل الأيض الأساسي", "基础代谢率所用性别"],
    "Grade average result": ["ग्रेड औसत परिणाम", "اوسط گریڈ کا نتیجہ", "Resultado del promedio de notas", "Résultat de la moyenne", "Notendurchschnitt-Ergebnis", "نتيجة متوسط الدرجات", "成绩平均值结果"],
    "Insert abs(": ["abs( डालें", "abs( داخل کریں", "Insertar abs(", "Insérer abs(", "abs( einfügen", "إدراج abs(", "插入 abs("],
    "Insert cos inverse (": ["cos inverse डालें", "cos inverse داخل کریں", "Insertar cos inverso", "Insérer cos inverse", "cos inverse einfügen", "إدراج cos العكسي", "插入反余弦"],
    "Insert cos(": ["cos( डालें", "cos( داخل کریں", "Insertar cos(", "Insérer cos(", "cos( einfügen", "إدراج cos(", "插入 cos("],
    "Insert cosh(": ["cosh( डालें", "cosh( داخل کریں", "Insertar cosh(", "Insérer cosh(", "cosh( einfügen", "إدراج cosh(", "插入 cosh("],
    "Insert cube root glyph ∛": ["घनमूल चिह्न ∛ डालें", "مکعب جذر کی علامت ∛ داخل کریں", "Insertar el símbolo de raíz cúbica ∛", "Insérer le symbole de racine cubique ∛", "Kubikwurzelzeichen ∛ einfügen", "إدراج رمز الجذر التكعيبي ∛", "插入立方根符号 ∛"],
    "Insert factorial !": ["फैक्टोरियल ! डालें", "فیکٹوریل ! داخل کریں", "Insertar factorial !", "Insérer factorielle !", "Fakultät ! einfügen", "إدراج المضروب !", "插入阶乘 !"],
    "Insert ln(": ["ln( डालें", "ln( داخل کریں", "Insertar ln(", "Insérer ln(", "ln( einfügen", "إدراج ln(", "插入 ln("],
    "Insert log(": ["log( डालें", "log( داخل کریں", "Insertar log(", "Insérer log(", "log( einfügen", "إدراج log(", "插入 log("],
    "Insert log₂(": ["log₂( डालें", "log₂( داخل کریں", "Insertar log₂(", "Insérer log₂(", "log₂( einfügen", "إدراج log₂(", "插入 log₂("],
    "Insert percent %": ["प्रतिशत % डालें", "فیصد % داخل کریں", "Insertar porcentaje %", "Insérer pourcentage %", "Prozent % einfügen", "إدراج النسبة المئوية %", "插入百分号 %"],
    "Insert power operator ^": ["घात ऑपरेटर ^ डालें", "طاقت کا آپریٹر ^ داخل کریں", "Insertar operador de potencia ^", "Insérer l’opérateur puissance ^", "Potenzoperator ^ einfügen", "إدراج عامل الأس ^", "插入幂运算符 ^"],
    "Insert reciprocal 1/(": ["व्युत्क्रम 1/( डालें", "معکوس 1/( داخل کریں", "Insertar recíproco 1/(", "Insérer l’inverse 1/(", "Kehrwert 1/( einfügen", "إدراج المقلوب 1/(", "插入倒数 1/("],
    "Insert scientific exponent E (×10^n)": ["वैज्ञानिक घातांक E (×10^n) डालें", "سائنسی ایکسپوننٹ E (×10^n) داخل کریں", "Insertar exponente científico E (×10^n)", "Insérer l’exposant scientifique E (×10^n)", "Wissenschaftlichen Exponenten E (×10^n) einfügen", "إدراج الأس العلمي E (×10^n)", "插入科学计数指数 E (×10^n)"],
    "Insert sin inverse (": ["sin inverse डालें", "sin inverse داخل کریں", "Insertar seno inverso", "Insérer sinus inverse", "sin inverse einfügen", "إدراج sin العكسي", "插入反正弦"],
    "Insert sin(": ["sin( डालें", "sin( داخل کریں", "Insertar sin(", "Insérer sin(", "sin( einfügen", "إدراج sin(", "插入 sin("],
    "Insert sinh(": ["sinh( डालें", "sinh( داخل کریں", "Insertar sinh(", "Insérer sinh(", "sinh( einfügen", "إدراج sinh(", "插入 sinh("],
    "Insert square root glyph √": ["वर्गमूल चिह्न √ डालें", "مربع جذر کی علامت √ داخل کریں", "Insertar símbolo de raíz cuadrada √", "Insérer le symbole de racine carrée √", "Quadratwurzelzeichen √ einfügen", "إدراج رمز الجذر التربيعي √", "插入平方根符号 √"],
    "Insert tan inverse (": ["tan inverse डालें", "tan inverse داخل کریں", "Insertar tangente inversa", "Insérer tangente inverse", "tan inverse einfügen", "إدراج tan العكسي", "插入反正切"],
    "Insert tan(": ["tan( डालें", "tan( داخل کریں", "Insertar tan(", "Insérer tan(", "tan( einfügen", "إدراج tan(", "插入 tan("],
    "Insert tanh(": ["tanh( डालें", "tanh( داخل کریں", "Insertar tanh(", "Insérer tanh(", "tanh( einfügen", "إدراج tanh(", "插入 tanh("],
    "Insert π constant": ["π स्थिरांक डालें", "π مستقل داخل کریں", "Insertar constante π", "Insérer la constante π", "Konstante π einfügen", "إدراج الثابت π", "插入常数 π"],
    "Interest compounding frequency": ["ब्याज चक्रवृद्धि आवृत्ति", "سود مرکب ہونے کی مدت", "Frecuencia de capitalización", "Fréquence de capitalisation", "Zinseszinsintervall", "وتيرة احتساب الفائدة المركبة", "复利频率"],
    "Jump to currency letter": ["मुद्रा के अक्षर पर जाएँ", "کرنسی کے حرف پر جائیں", "Ir a la letra de moneda", "Aller à la lettre de devise", "Zum Währungsbuchstaben springen", "الانتقال إلى حرف العملة", "跳转到货币字母"],
    "Keep screen awake": ["स्क्रीन चालू रखें", "اسکرین روشن رکھیں", "Mantener pantalla activa", "Garder l’écran actif", "Bildschirm eingeschaltet lassen", "إبقاء الشاشة قيد التشغيل", "保持屏幕常亮"],
    "Loan repayment method": ["ऋण भुगतान विधि", "قرض کی واپسی کا طریقہ", "Método de amortización del préstamo", "Mode de remboursement du prêt", "Kreditrückzahlungsmethode", "طريقة سداد القرض", "贷款还款方式"],
    "Maximum history entries": ["इतिहास की अधिकतम प्रविष्टियाँ", "ہسٹری کی زیادہ سے زیادہ اندراجات", "Máximo de entradas del historial", "Nombre maximal d’entrées de l’historique", "Maximale Verlaufseinträge", "الحد الأقصى لعناصر السجل", "历史记录最大条数"],
    "Memory Add": ["मेमोरी में जोड़ें", "میموری میں جمع کریں", "Sumar a memoria", "Ajouter à la mémoire", "Zum Speicher addieren", "إضافة إلى الذاكرة", "存储器加"],
    "Memory Clear": ["मेमोरी साफ़ करें", "میموری صاف کریں", "Borrar memoria", "Effacer la mémoire", "Speicher löschen", "مسح الذاكرة", "清除存储器"],
    "Memory Recall": ["मेमोरी वापस लाएँ", "میموری واپس لیں", "Recuperar memoria", "Rappeler la mémoire", "Speicher abrufen", "استدعاء الذاكرة", "存储器读取"],
    "Memory Store": ["मेमोरी में सहेजें", "میموری میں محفوظ کریں", "Guardar en memoria", "Enregistrer en mémoire", "Im Speicher speichern", "تخزين في الذاكرة", "存入存储器"],
    "Memory Subtract": ["मेमोरी से घटाएँ", "میموری سے منہا کریں", "Restar de memoria", "Soustraire de la mémoire", "Vom Speicher abziehen", "طرح من الذاكرة", "存储器减"],
    "Navigation Menu": ["नेविगेशन मेनू", "نیویگیشن مینو", "Menú de navegación", "Menu de navigation", "Navigationsmenü", "قائمة التنقل", "导航菜单"],
    "Next input": ["अगला इनपुट", "اگلا ان پٹ", "Siguiente entrada", "Saisie suivante", "Nächste Eingabe", "الإدخال التالي", "下一个输入"],
    "Number base inputs": ["संख्या आधार इनपुट", "نمبر بیس ان پٹس", "Entradas de base numérica", "Entrées de base numérique", "Zahlensystem-Eingaben", "مدخلات أساس العدد", "进制输入"],
    "Open calculation history": ["गणना इतिहास खोलें", "حساب کی ہسٹری کھولیں", "Abrir historial de cálculos", "Ouvrir l’historique des calculs", "Berechnungsverlauf öffnen", "فتح سجل الحسابات", "打开计算历史记录"],
    "Open navigation menu": ["नेविगेशन मेनू खोलें", "نیویگیشن مینو کھولیں", "Abrir menú de navegación", "Ouvrir le menu de navigation", "Navigationsmenü öffnen", "فتح قائمة التنقل", "打开导航菜单"],
    "Open scientific functions": ["वैज्ञानिक फ़ंक्शन खोलें", "سائنسی فنکشنز کھولیں", "Abrir funciones científicas", "Ouvrir les fonctions scientifiques", "Wissenschaftliche Funktionen öffnen", "فتح الدوال العلمية", "打开科学函数"],
    "Open settings": ["सेटिंग खोलें", "ترتیبات کھولیں", "Abrir ajustes", "Ouvrir les paramètres", "Einstellungen öffnen", "فتح الإعدادات", "打开设置"],
    "Product A price": ["उत्पाद A की कीमत", "پروڈکٹ A کی قیمت", "Precio del producto A", "Prix du produit A", "Preis von Produkt A", "سعر المنتج A", "产品 A 价格"],
    "Product A quantity": ["उत्पाद A की मात्रा", "پروڈکٹ A کی مقدار", "Cantidad del producto A", "Quantité du produit A", "Menge von Produkt A", "كمية المنتج A", "产品 A 数量"],
    "Product B price": ["उत्पाद B की कीमत", "پروڈکٹ B کی قیمت", "Precio del producto B", "Prix du produit B", "Preis von Produkt B", "سعر المنتج B", "产品 B 价格"],
    "Product B quantity": ["उत्पाद B की मात्रा", "پروڈکٹ B کی مقدار", "Cantidad del producto B", "Quantité du produit B", "Menge von Produkt B", "كمية المنتج B", "产品 B 数量"],
    "Product C price": ["उत्पाद C की कीमत", "پروڈکٹ C کی قیمت", "Precio del producto C", "Prix du produit C", "Preis von Produkt C", "سعر المنتج C", "产品 C 价格"],
    "Product C quantity": ["उत्पाद C की मात्रा", "پروڈکٹ C کی مقدار", "Cantidad del producto C", "Quantité du produit C", "Menge von Produkt C", "كمية المنتج C", "产品 C 数量"],
    "Product D price": ["उत्पाद D की कीमत", "پروڈکٹ D کی قیمت", "Precio del producto D", "Prix du produit D", "Preis von Produkt D", "سعر المنتج D", "产品 D 价格"],
    "Product D quantity": ["उत्पाद D की मात्रा", "پروڈکٹ D کی مقدار", "Cantidad del producto D", "Quantité du produit D", "Menge von Produkt D", "كمية المنتج D", "产品 D 数量"],
    "Record calculation history": ["गणना इतिहास रिकॉर्ड करें", "حساب کی ہسٹری ریکارڈ کریں", "Registrar historial de cálculos", "Enregistrer l’historique des calculs", "Berechnungsverlauf aufzeichnen", "تسجيل سجل الحسابات", "记录计算历史"],
    "Refresh currency rates": ["मुद्रा दरें रीफ़्रेश करें", "کرنسی شرحیں تازہ کریں", "Actualizar tipos de cambio", "Actualiser les taux de change", "Wechselkurse aktualisieren", "تحديث أسعار العملات", "刷新汇率"],
    "Repeat this event every year": ["इस कार्यक्रम को हर साल दोहराएँ", "اس ایونٹ کو ہر سال دہرائیں", "Repetir este evento cada año", "Répéter cet événement chaque année", "Dieses Ereignis jedes Jahr wiederholen", "تكرار هذا الحدث كل عام", "每年重复此事件"],
    "Restore previous inputs": ["पिछले इनपुट पुनर्स्थापित करें", "پچھلے ان پٹس بحال کریں", "Restaurar entradas anteriores", "Restaurer les saisies précédentes", "Vorherige Eingaben wiederherstellen", "استعادة المدخلات السابقة", "恢复之前的输入"],
    "Result decimal precision": ["परिणाम की दशमलव सटीकता", "نتیجے کی اعشاری درستگی", "Precisión decimal del resultado", "Précision décimale du résultat", "Dezimalgenauigkeit des Ergebnisses", "دقة الكسور العشرية للنتيجة", "结果小数精度"],
    "Search currencies": ["मुद्राएँ खोजें", "کرنسیاں تلاش کریں", "Buscar monedas", "Rechercher des devises", "Währungen suchen", "البحث عن العملات", "搜索货币"],
    "Search world cities": ["विश्व के शहर खोजें", "دنیا کے شہر تلاش کریں", "Buscar ciudades del mundo", "Rechercher des villes du monde", "Weltstädte suchen", "البحث عن مدن العالم", "搜索世界城市"],
    "Select a city or time zone": ["शहर या समय क्षेत्र चुनें", "شہر یا ٹائم زون منتخب کریں", "Seleccionar ciudad o zona horaria", "Sélectionner une ville ou un fuseau horaire", "Stadt oder Zeitzone auswählen", "اختر مدينة أو منطقة زمنية", "选择城市或时区"],
    "Show trailing zeros": ["अंतिम शून्य दिखाएँ", "آخری صفر دکھائیں", "Mostrar ceros finales", "Afficher les zéros finaux", "Nachgestellte Nullen anzeigen", "إظهار الأصفار اللاحقة", "显示末尾零"],
    "Source unit": ["स्रोत इकाई", "ماخذ اکائی", "Unidad de origen", "Unité source", "Ausgangseinheit", "وحدة المصدر", "源单位"],
    "Scientific Functions": ["वैज्ञानिक फ़ंक्शन", "سائنسی فنکشنز", "Funciones científicas", "Fonctions scientifiques", "Wissenschaftliche Funktionen", "الدوال العلمية", "科学函数"],
    "Scientific calculator angle mode": ["वैज्ञानिक कैलकुलेटर कोण मोड", "سائنسی کیلکولیٹر زاویہ موڈ", "Modo angular de la calculadora científica", "Mode angulaire de la calculatrice scientifique", "Winkelmodus des wissenschaftlichen Rechners", "وضع الزاوية للآلة الحاسبة العلمية", "科学计算器角度模式"],
    "Scientific exponent (×10^n)": ["वैज्ञानिक घातांक (×10^n)", "سائنسی ایکسپوننٹ (×10^n)", "Exponente científico (×10^n)", "Exposant scientifique (×10^n)", "Wissenschaftlicher Exponent (×10^n)", "الأس العلمي (×10^n)", "科学指数（×10^n）"],
    "Swap Units": ["इकाइयाँ बदलें", "اکائیاں تبدیل کریں", "Intercambiar unidades", "Permuter les unités", "Einheiten tauschen", "تبديل الوحدات", "交换单位"],
    "Swap currencies": ["मुद्राएँ बदलें", "کرنسیاں تبدیل کریں", "Intercambiar monedas", "Permuter les devises", "Währungen tauschen", "تبديل العملات", "交换货币"],
    "Target unit": ["लक्ष्य इकाई", "منزل اکائی", "Unidad de destino", "Unité cible", "Zieleinheit", "وحدة الهدف", "目标单位"],
    "Tax calculation mode": ["कर गणना मोड", "ٹیکس حساب کا طریقہ", "Modo de cálculo de impuestos", "Mode de calcul de taxe", "Steuerberechnungsmodus", "وضع حساب الضريبة", "税额计算模式"],
    "Thousands separator": ["हज़ार विभाजक", "ہزاروں کا جداکار", "Separador de miles", "Séparateur de milliers", "Tausendertrennzeichen", "فاصل الآلاف", "千位分隔符"],
    "To currency": ["लक्ष्य मुद्रा", "مطلوبہ کرنسی", "Moneda de destino", "Devise cible", "Zielwährung", "عملة الوجهة", "目标货币"],
    "Unit category": ["इकाई श्रेणी", "اکائی کی قسم", "Categoría de unidades", "Catégorie d’unités", "Einheitenkategorie", "فئة الوحدات", "单位类别"],
    "Vibration strength": ["कंपन तीव्रता", "ارتعاش کی شدت", "Intensidad de vibración", "Intensité des vibrations", "Vibrationsstärke", "شدة الاهتزاز", "振动强度"],
    "Write a short description before copying": ["कॉपी करने से पहले छोटा विवरण लिखें", "کاپی کرنے سے پہلے مختصر وضاحت لکھیں", "Escribe una breve descripción antes de copiar", "Rédigez une courte description avant de copier", "Schreiben Sie vor dem Kopieren eine kurze Beschreibung", "اكتب وصفًا قصيرًا قبل النسخ", "复制前请填写简短说明"],
    "Screen wake lock is unavailable or permission was denied": ["स्क्रीन सक्रिय रखने की सुविधा उपलब्ध नहीं है या अनुमति अस्वीकृत हुई", "اسکرین کو بیدار رکھنے کی سہولت دستیاب نہیں یا اجازت مسترد ہوگئی", "La función para mantener la pantalla activa no está disponible o se denegó el permiso", "Le maintien de l’écran actif est indisponible ou l’autorisation a été refusée", "Bildschirm-Aktivsperre nicht verfügbar oder Berechtigung verweigert", "ميزة إبقاء الشاشة نشطة غير متاحة أو تم رفض الإذن", "屏幕常亮功能不可用或权限被拒绝"],
    "Sharing is unavailable; use Copy report instead": ["शेयर करना उपलब्ध नहीं है; इसके बजाय रिपोर्ट कॉपी करें", "شیئرنگ دستیاب نہیں؛ اس کے بجائے رپورٹ کاپی کریں", "Compartir no está disponible; copia el informe", "Le partage est indisponible ; copiez plutôt le rapport", "Teilen nicht verfügbar; kopieren Sie stattdessen den Bericht", "المشاركة غير متاحة؛ استخدم نسخ التقرير بدلاً من ذلك", "暂无法分享；请改为复制报告"],
    "Report copied. You can paste it into your support channel.": ["रिपोर्ट कॉपी हो गई। आप इसे अपने सहायता चैनल में पेस्ट कर सकते हैं।", "رپورٹ کاپی ہوگئی۔ آپ اسے اپنے سپورٹ چینل میں پیسٹ کر سکتے ہیں۔", "Informe copiado. Puedes pegarlo en tu canal de soporte.", "Rapport copié. Vous pouvez le coller dans votre canal d’assistance.", "Bericht kopiert. Sie können ihn in Ihren Support-Kanal einfügen.", "تم نسخ التقرير. يمكنك لصقه في قناة الدعم.", "报告已复制。您可以将其粘贴到支持渠道。"],
  });
  Object.assign(rows, {
    "Times are shown in your device's local time.": ['समय आपके डिवाइस के स्थानीय समय के अनुसार दिखाया जाता है।','اوقات آپ کے آلے کے مقامی وقت کے مطابق دکھائے جاتے ہیں۔','Las horas se muestran según la hora local de tu dispositivo.','Les heures sont affichées selon l’heure locale de votre appareil.','Zeiten werden in der Ortszeit Ihres Geräts angezeigt.','تُعرض الأوقات وفق التوقيت المحلي لجهازك.','时间按您设备的本地时间显示。'],
  });

  // Remaining visible settings, form labels, themes and helper copy.
  Object.assign(rows, {
    "Accent palette": ["रंग पैलेट", "رنگوں کا مجموعہ", "Paleta de acentos", "Palette d’accentuation", "Akzentpalette", "لوحة الألوان", "لوحة الألوان"],
    "Amount of refueled gasoline (L)": ["भरे गए पेट्रोल की मात्रा (लीटर)", "بھروائے گئے پٹرول کی مقدار (لیٹر)", "Cantidad de gasolina repostada (L)", "Quantité d’essence ravitaillée (L)", "Getankte Kraftstoffmenge (L)", "كمية الوقود المضافة (لتر)", "加注燃油量（升）"],
    "BMI & BMR": ["BMI और BMR", "BMI اور BMR", "IMC y TMB", "IMC et MB", "BMI und BMR", "BMI وBMR", "BMI 与 BMR"],
    "Base Reference Time · Kolkata": ["आधार संदर्भ समय · कोलकाता", "بنیادی حوالہ وقت · کولکاتا", "Hora de referencia base · Calcuta", "Heure de référence · Calcutta", "Basis-Referenzzeit · Kolkata", "الوقت المرجعي الأساسي · كولكاتا", "基准参考时间 · 加尔各答"],
    "Body Metrics Calculator": ["शरीर माप कैलकुलेटर", "جسمانی پیمائش کیلکولیٹر", "Calculadora de medidas corporales", "Calculateur de mesures corporelles", "Körpermaßrechner", "حاسبة قياسات الجسم", "身体指标计算器"],
    "Cancel": ["रद्द करें", "منسوخ کریں", "Cancelar", "Annuler", "Abbrechen", "إلغاء", "取消"],
    "Changes the language of app labels, controls, messages and supported instructions.": ["ऐप के लेबल, नियंत्रण, संदेश और उपलब्ध निर्देशों की भाषा बदलें।", "ایپ کے لیبل، کنٹرولز، پیغامات اور دستیاب ہدایات کی زبان تبدیل کریں۔", "Cambia el idioma de las etiquetas, controles, mensajes e instrucciones disponibles.", "Change la langue des libellés, commandes, messages et instructions disponibles.", "Ändert die Sprache der Beschriftungen, Steuerelemente, Meldungen und verfügbaren Anleitungen.", "يغيّر لغة التسميات وعناصر التحكم والرسائل والتعليمات المتاحة في التطبيق.", "更改应用标签、控件、消息和可用说明的语言。"],
    "Clear Data": ["डेटा साफ़ करें", "ڈیٹا صاف کریں", "Borrar datos", "Effacer les données", "Daten löschen", "مسح البيانات", "清除数据"],
    "Click": ["क्लिक करें", "کلک کریں", "Hacer clic", "Cliquer", "Klicken", "انقر", "点击"],
    "Discount, Percent, Sales Tax, Body Metrics, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip, Unit Price and World Time are available from the navigation drawer.": ["नेविगेशन मेनू में छूट, प्रतिशत, बिक्री कर, शरीर माप, तारीख, ईंधन लागत, ईंधन दक्षता, ग्रेड औसत, संख्या आधार, ऋण/EMI, बचत, टिप, इकाई मूल्य और विश्व समय उपलब्ध हैं।", "نیویگیشن مینو میں رعایت، فیصد، سیلز ٹیکس، جسمانی پیمائش، تاریخ، ایندھن لاگت، ایندھن کی کارکردگی، اوسط گریڈ، نمبر بیس، قرض/EMI، بچت، ٹپ، فی یونٹ قیمت اور عالمی وقت دستیاب ہیں۔", "En el menú de navegación están disponibles descuentos, porcentajes, impuestos, medidas corporales, fechas, combustible, eficiencia, notas, bases numéricas, préstamos/EMI, ahorros, propinas, precios unitarios y hora mundial.", "Le menu de navigation donne accès aux remises, pourcentages, taxes, mesures corporelles, dates, carburant, efficacité, notes, bases numériques, prêts/EMI, épargne, pourboires, prix unitaires et heure mondiale.", "Im Navigationsmenü stehen Rabatt, Prozent, Umsatzsteuer, Körpermaße, Datum, Kraftstoffkosten und -effizienz, Notendurchschnitt, Zahlensysteme, Kredit/EMI, Sparen, Trinkgeld, Stückpreis und Weltzeit zur Verfügung.", "تتوفر في قائمة التنقل أدوات الخصم والنسبة المئوية وضريبة المبيعات وقياسات الجسم والتاريخ وتكلفة الوقود وكفاءته ومتوسط الدرجات وأنظمة الأعداد والقروض/EMI والمدخرات والإكرامية وسعر الوحدة والتوقيت العالمي.", "导航菜单提供折扣、百分比、销售税、身体指标、日期、燃油成本、燃油效率、成绩平均值、进制、贷款/分期、储蓄、小费、单价和世界时间工具。"],
    "Feedback & bug report": ["प्रतिक्रिया और बग रिपोर्ट", "رائے اور بگ رپورٹ", "Comentarios e informe de errores", "Commentaires et rapport de bogue", "Feedback und Fehlerbericht", "الملاحظات والإبلاغ عن الأخطاء", "反馈与错误报告"],
    "From Unit": ["स्रोत इकाई", "ماخذ اکائی", "Unidad de origen", "Unité source", "Ausgangseinheit", "وحدة المصدر", "源单位"],
    "Independent product": ["स्वतंत्र उत्पाद", "آزاد پروڈکٹ", "Producto independiente", "Produit indépendant", "Unabhängiges Produkt", "منتج مستقل", "独立商品"],
    "Input": ["इनपुट", "ان پٹ", "Entrada", "Entrée", "Eingabe", "إدخال", "输入"],
    "Interest": ["ब्याज", "سود", "Interés", "Intérêt", "Zinsen", "الفائدة", "利息"],
    "L/100 km": ["लीटर/100 किमी", "لیٹر/100 کلومیٹر", "L/100 km", "L/100 km", "L/100 km", "لتر/100 كم", "升/100公里"],
    "Light (15ms)": ["हल्का (15ms)", "ہلکا (15ms)", "Ligera (15 ms)", "Léger (15 ms)", "Leicht (15 ms)", "خفيف (15 مللي ثانية)", "轻（15 毫秒）"],
    "Local Offline Sandbox": ["स्थानीय ऑफ़लाइन वातावरण", "مقامی آف لائن ماحول", "Entorno local sin conexión", "Environnement local hors ligne", "Lokale Offline-Umgebung", "بيئة محلية دون اتصال", "本地离线环境"],
    "Medium (30ms)": ["मध्यम (30ms)", "درمیانہ (30ms)", "Media (30 ms)", "Moyen (30 ms)", "Mittel (30 ms)", "متوسط (30 مللي ثانية)", "中（30 毫秒）"],
    "Month": ["महीना", "مہینہ", "Mes", "Mois", "Monat", "شهر", "月"],
    "Monthly": ["मासिक", "ماہانہ", "Mensual", "Mensuel", "Monatlich", "شهريًا", "每月"],
    "M−": ["M−", "M−", "M−", "M−", "M−", "M−", "M−"],
    "Ocean Glass": ["ओशन ग्लास", "اوشن گلاس", "Cristal océano", "Verre océan", "Ocean-Glas", "زجاج المحيط", "海洋玻璃"],
    "Orange": ["नारंगी", "نارنجی", "Naranja", "Orange", "Orange", "برتقالي", "橙色"],
    "Pink": ["गुलाबी", "گلابی", "Rosa", "Rose", "Rosa", "وردي", "粉色"],
    "Quarterly": ["त्रैमासिक", "سہ ماہی", "Trimestral", "Trimestriel", "Vierteljährlich", "ربع سنوي", "每季度"],
    "Remove locally saved app data and browser cache.": ["स्थानीय रूप से सहेजा गया ऐप डेटा और ब्राउज़र कैश हटाएँ।", "مقامی طور پر محفوظ ایپ ڈیٹا اور براؤزر کیش حذف کریں۔", "Eliminar los datos locales de la aplicación y la caché del navegador.", "Supprimer les données locales de l’application et le cache du navigateur.", "Lokal gespeicherte App-Daten und Browsercache entfernen.", "إزالة بيانات التطبيق المحفوظة محليًا وذاكرة التخزين المؤقت للمتصفح.", "删除本地保存的应用数据和浏览器缓存。"],
    "Reset": ["रीसेट करें", "ری سیٹ کریں", "Restablecer", "Réinitialiser", "Zurücksetzen", "إعادة ضبط", "重置"],
    "SA Calculator quick guide": ["SA Calculator त्वरित मार्गदर्शिका", "SA Calculator فوری رہنما", "Guía rápida de SA Calculator", "Guide rapide de SA Calculator", "SA Calculator Kurzanleitung", "دليل SA Calculator السريع", "SA Calculator 快速指南"],
    "Semi-annually": ["अर्धवार्षिक", "ششماہی", "Semestralmente", "Semestriellement", "Halbjährlich", "نصف سنوي", "每半年"],
    "Share": ["साझा करें", "شیئر کریں", "Compartir", "Partager", "Teilen", "مشاركة", "分享"],
    "Strong (50ms)": ["तेज़ (50ms)", "مضبوط (50ms)", "Fuerte (50 ms)", "Fort (50 ms)", "Stark (50 ms)", "قوي (50 مللي ثانية)", "强（50 毫秒）"],
    "Teal": ["टील", "سبز مائل نیلا", "Verde azulado", "Sarcelle", "Blaugrün", "أزرق مخضر", "蓝绿色"],
    "Teal Green (#00897b)": ["टील हरा (#00897b)", "سبز مائل نیلا (#00897b)", "Verde azulado (#00897b)", "Vert sarcelle (#00897b)", "Blaugrün (#00897b)", "أخضر مزرق (#00897b)", "蓝绿色 (#00897b)"],
    "To Unit": ["लक्ष्य इकाई", "منزل اکائی", "Unidad de destino", "Unité cible", "Zieleinheit", "وحدة الهدف", "目标单位"],
    "Tools, conversions, history and settings": ["टूल, रूपांतरण, इतिहास और सेटिंग", "ٹولز، تبدیلیاں، ہسٹری اور ترتیبات", "Herramientas, conversiones, historial y ajustes", "Outils, conversions, historique et paramètres", "Werkzeuge, Umrechnungen, Verlauf und Einstellungen", "الأدوات والتحويلات والسجل والإعدادات", "工具、转换、历史记录和设置"],
    "Value": ["मान", "قدر", "Valor", "Valeur", "Wert", "القيمة", "数值"],
    "Vector Blue": ["वेक्टर नीला", "ویکٹر نیلا", "Azul vectorial", "Bleu vectoriel", "Vektorblau", "أزرق متجهي", "矢量蓝"],
    "Version": ["संस्करण", "ورژن", "Versión", "Version", "Version", "الإصدار", "版本"],
    "Weight (kg)": ["वज़न (किग्रा)", "وزن (کلوگرام)", "Peso (kg)", "Poids (kg)", "Gewicht (kg)", "الوزن (كجم)", "体重（公斤）"],
    "Yellow": ["पीला", "پیلا", "Amarillo", "Jaune", "Gelb", "أصفر", "黄色"],
    "Square root (√)": ["वर्गमूल (√)", "مربع جذر (√)", "Raíz cuadrada (√)", "Racine carrée (√)", "Quadratwurzel (√)", "الجذر التربيعي (√)", "平方根（√）"],
    "Startup screen": ["शुरुआती स्क्रीन", "ابتدائی اسکرین", "Pantalla de inicio", "Écran de démarrage", "Startbildschirm", "شاشة بدء التشغيل", "启动屏幕"],
    "100 Entries": ["100 प्रविष्टियाँ", "100 اندراجات", "100 entradas", "100 entrées", "100 Einträge", "100 إدخال", "100 条记录"],
    "25 Entries": ["25 प्रविष्टियाँ", "25 اندراجات", "25 entradas", "25 entrées", "25 Einträge", "25 إدخال", "25 条记录"],
    "50 Entries (Default)": ["50 प्रविष्टियाँ (डिफ़ॉल्ट)", "50 اندراجات (ڈیفالٹ)", "50 entradas (predeterminado)", "50 entrées (par défaut)", "50 Einträge (Standard)", "50 إدخال (افتراضي)", "50 条记录（默认）"],
    "500 Entries": ["500 प्रविष्टियाँ", "500 اندراجات", "500 entradas", "500 entrées", "500 Einträge", "500 إدخال", "500 条记录"],
    "2 Decimals": ["2 दशमलव स्थान", "2 اعشاری مقامات", "2 decimales", "2 décimales", "2 Dezimalstellen", "منزلتان عشريتان", "2 位小数"],
    "4 Decimals (Scientific/Precision)": ["4 दशमलव (वैज्ञानिक/सटीकता)", "4 اعشاری (سائنسی/درستگی)", "4 decimales (científico/precisión)", "4 décimales (scientifique/précision)", "4 Dezimalstellen (wissenschaftlich/Präzision)", "4 منازل عشرية (علمي/دقة)", "4 位小数（科学/精度）"],
    "6 Decimals (High Precision)": ["6 दशमलव (उच्च सटीकता)", "6 اعشاری (اعلیٰ درستگی)", "6 decimales (alta precisión)", "6 décimales (haute précision)", "6 Dezimalstellen (hohe Präzision)", "6 منازل عشرية (دقة عالية)", "6 位小数（高精度）"],
    "1 234 567.89 (International)": ["1 234 567.89 (अंतरराष्ट्रीय)", "1 234 567.89 (بین الاقوامی)", "1 234 567.89 (internacional)", "1 234 567,89 (international)", "1 234 567,89 (international)", "1 234 567.89 (دولي)", "1 234 567.89（国际）"],
    "1,234,567.89 (Standard)": ["1,234,567.89 (मानक)", "1,234,567.89 (معیاری)", "1,234,567.89 (estándar)", "1 234 567,89 (standard)", "1.234.567,89 (Standard)", "1,234,567.89 (قياسي)", "1,234,567.89（标准）"],
    "12,34,567.89 (South Asian)": ["12,34,567.89 (दक्षिण एशियाई)", "12,34,567.89 (جنوبی ایشیائی)", "12,34,567.89 (surasiático)", "12,34,567.89 (Asie du Sud)", "12,34,567.89 (Südasien)", "12,34,567.89 (جنوب آسيوي)", "12,34,567.89（南亚）"],
    "1234567.89 (No Separator)": ["1234567.89 (बिना विभाजक)", "1234567.89 (بغیر جداکار)", "1234567.89 (sin separador)", "1234567,89 (sans séparateur)", "1234567,89 (ohne Trennzeichen)", "1234567.89 (بلا فاصل)", "1234567.89（无分隔符）"],
    "English (Default)": ["अंग्रेज़ी (डिफ़ॉल्ट)", "انگریزی (ڈیفالٹ)", "Inglés (predeterminado)", "Anglais (par défaut)", "Englisch (Standard)", "الإنجليزية (افتراضي)", "英语（默认）"],
  });

  // Dynamic feedback, validation and error messages.
  Object.assign(rows, {
    "Copied": ["कॉपी किया गया", "کاپی ہوگیا", "Copiado", "Copié", "Kopiert", "تم النسخ", "已复制"],
    "Diagnostics are local only; nothing is uploaded": ["डायग्नोस्टिक्स केवल स्थानीय हैं; कुछ भी अपलोड नहीं होता", "تشخیصی معلومات صرف مقامی ہیں؛ کچھ اپ لوڈ نہیں ہوتا", "Los diagnósticos son locales; no se sube nada", "Les diagnostics restent locaux ; rien n’est envoyé", "Diagnosen bleiben lokal; es wird nichts hochgeladen", "التشخيص محلي فقط؛ لا يتم رفع أي شيء", "诊断仅在本地进行；不会上传任何内容"],
    "Expression limit: 250 characters": ["अभिव्यक्ति सीमा: 250 अक्षर", "اظہار کی حد: 250 حروف", "Límite de expresión: 250 caracteres", "Limite d’expression : 250 caractères", "Ausdruckslimit: 250 Zeichen", "حد التعبير: 250 حرفًا", "表达式上限：250 个字符"],
    "Maximum {count} significant digits for accurate results": ["सटीक परिणामों के लिए अधिकतम {count} सार्थक अंक", "درست نتائج کے لیے زیادہ سے زیادہ {count} بامعنی ہندسے", "Máximo de {count} cifras significativas para resultados precisos", "Maximum {count} chiffres significatifs pour des résultats précis", "Maximal {count} signifikante Stellen für genaue Ergebnisse", "الحد الأقصى {count} رقمًا معنويًا للحصول على نتائج دقيقة", "为确保结果准确，最多允许 {count} 位有效数字"],
    "Maximum {count} significant digits per number": ["प्रति संख्या अधिकतम {count} सार्थक अंक", "ہر عدد میں زیادہ سے زیادہ {count} بامعنی ہندسے", "Máximo de {count} cifras significativas por número", "Maximum {count} chiffres significatifs par nombre", "Maximal {count} signifikante Stellen pro Zahl", "الحد الأقصى {count} رقمًا معنويًا لكل عدد", "每个数字最多允许 {count} 位有效数字"],
    "Date updated and saved": ["तारीख अपडेट और सहेजी गई", "تاریخ اپ ڈیٹ اور محفوظ ہوگئی", "Fecha actualizada y guardada", "Date mise à jour et enregistrée", "Datum aktualisiert und gespeichert", "تم تحديث التاريخ وحفظه", "日期已更新并保存"],
    "Date saved": ["तारीख सहेजी गई", "تاریخ محفوظ ہوگئی", "Fecha guardada", "Date enregistrée", "Datum gespeichert", "تم حفظ التاريخ", "日期已保存"],
    "Cached data cleared successfully": ["कैश डेटा सफलतापूर्वक साफ़ किया गया", "کیش ڈیٹا کامیابی سے صاف ہوگیا", "Datos en caché borrados correctamente", "Données en cache effacées avec succès", "Cache-Daten erfolgreich gelöscht", "تم مسح البيانات المخزنة مؤقتًا بنجاح", "缓存数据已成功清除"],
    "Cache cleanup completed with {count} verification issue(s)": ["कैश सफाई पूरी हुई; सत्यापन में {count} समस्या मिली", "کیش صفائی مکمل؛ تصدیق میں {count} مسئلہ ملا", "Limpieza de caché completada con {count} problema(s) de verificación", "Nettoyage du cache terminé avec {count} problème(s) de vérification", "Cache-Bereinigung abgeschlossen; {count} Prüfproblem(e) gefunden", "اكتمل تنظيف ذاكرة التخزين المؤقت مع {count} مشكلة تحقق", "缓存清理完成，发现 {count} 个验证问题"],
  });

  // Screen section titles and theme palette labels.
  Object.assign(rows, {
    "10. SOUND & VIBRATION": ["10. ध्वनि और कंपन", "10. آواز اور ارتعاش", "10. SONIDO Y VIBRACIÓN", "10. SON ET VIBRATION", "10. TON UND VIBRATION", "10. الصوت والاهتزاز", "10. 声音与振动"],
    "12. ABOUT & SUPPORT": ["12. जानकारी और सहायता", "12. معلومات اور معاونت", "12. ACERCA DE Y SOPORTE", "12. À PROPOS ET ASSISTANCE", "12. INFO & SUPPORT", "12. حول التطبيق والدعم", "12. 关于和支持"],
    "2. THEME & COLORS": ["2. थीम और रंग", "2. تھیم اور رنگ", "2. TEMAS Y COLORES", "2. THÈMES ET COULEURS", "2. DESIGNS & FARBEN", "2. السمات والألوان", "2. 主题与颜色"],
    "4. DECIMAL & NUMBER FORMAT": ["4. दशमलव और संख्या प्रारूप", "4. اعشاریہ اور نمبر فارمیٹ", "4. DECIMALES Y FORMATO NUMÉRICO", "4. DÉCIMALES ET FORMAT DES NOMBRES", "4. DEZIMAL- UND ZAHLENFORMAT", "4. تنسيق الأرقام والكسور", "4. 小数与数字格式"],
    "8. SCREEN: DATE CALCULATOR — date events and anniversaries": ["8. स्क्रीन: तारीख कैलकुलेटर — तारीख के कार्यक्रम और वर्षगाँठ", "8. اسکرین: تاریخ کیلکولیٹر — تاریخ کے واقعات اور سالگرہیں", "8. PANTALLA: CALCULADORA DE FECHAS — eventos y aniversarios", "8. ÉCRAN : CALCULATEUR DE DATES — événements et anniversaires", "8. BILDSCHIRM: DATUMSRECHNER — Ereignisse und Jahrestage", "8. الشاشة: حاسبة التواريخ — الأحداث والذكرى السنوية", "8. 页面：日期计算器 — 日期事件与周年纪念"],
    "10. SCREEN: FUEL EFFICIENCY — fill-to-fill method": ["10. स्क्रीन: ईंधन दक्षता — टैंक-से-टैंक विधि", "10. اسکرین: ایندھن کی کارکردگی — فل ٹو فل طریقہ", "10. PANTALLA: EFICIENCIA DE COMBUSTIBLE — método de depósito a depósito", "10. ÉCRAN : EFFICACITÉ ÉNERGÉTIQUE — méthode plein à plein", "10. BILDSCHIRM: KRAFTSTOFFEFFIZIENZ — Voll-zu-Voll-Methode", "10. الشاشة: كفاءة الوقود — طريقة ملء الخزان إلى ملئه", "10. 页面：燃油效率 — 满箱到满箱法"],
    "Blue": ["नीला", "نیلا", "Azul", "Bleu", "Blau", "أزرق", "蓝色"],
    "Brown": ["भूरा", "بھورا", "Marrón", "Marron", "Braun", "بني", "棕色"],
    "Cyan": ["सियान", "فیروزی", "Cian", "Bleu cyan", "Cyanblau", "سماوي", "青色"],
    "Grey": ["धूसर", "سرمئی", "Gris", "Gris", "Grau", "رمادي", "灰色"],
    "Indigo": ["इंडिगो", "نیلگوں", "Índigo", "Indigo", "Indigo", "نيلي", "靛蓝"],
    "Lime": ["लाइम", "لیموں سبز", "Lima", "Citron vert", "Limette", "ليموني", "酸橙绿"],
    "Midnight Teal": ["मिडनाइट टील", "مڈنائٹ ٹیل", "Verde azulado medianoche", "Sarcelle nuit", "Mitternachts-Petrol", "أزرق مخضر ليلي", "午夜蓝绿"],
    "Ocean Blue (#1976d2)": ["ओशन ब्लू (#1976d2)", "اوشن بلیو (#1976d2)", "Azul océano (#1976d2)", "Bleu océan (#1976d2)", "Ozeanblau (#1976d2)", "أزرق المحيط (#1976d2)", "海洋蓝（#1976d2）"],
    "Ocean Glass Blue (#1765f5)": ["ओशन ग्लास ब्लू (#1765f5)", "اوشن گلاس بلیو (#1765f5)", "Azul cristal océano (#1765f5)", "Bleu verre océan (#1765f5)", "Ocean-Glasblau (#1765f5)", "أزرق زجاج المحيط (#1765f5)", "海洋玻璃蓝（#1765f5）"],
    "Royal Purple (#6a1b9a)": ["रॉयल पर्पल (#6a1b9a)", "رائل پرپل (#6a1b9a)", "Púrpura real (#6a1b9a)", "Violet royal (#6a1b9a)", "Königsviolett (#6a1b9a)", "أرجواني ملكي (#6a1b9a)", "皇家紫（#6a1b9a）"],
    "Sepia": ["सेपिया", "سیپیا", "Sepia", "Sépia", "Sepia", "بني داكن", "深褐色"],
    "Vector Blue (#315fe8)": ["वेक्टर ब्लू (#315fe8)", "ویکٹر بلیو (#315fe8)", "Azul vectorial (#315fe8)", "Bleu vectoriel (#315fe8)", "Vektorblau (#315fe8)", "أزرق متجهي (#315fe8)", "矢量蓝（#315fe8）"],
  });

  // Dynamic currency-picker accessibility and localized empty states.
  Object.assign(rows, {
    "Jump to {letter}": ["अक्षर {letter} पर जाएँ", "حرف {letter} پر جائیں", "Ir a la letra {letter}", "Aller à la lettre {letter}", "Zum Buchstaben {letter} springen", "الانتقال إلى الحرف {letter}", "跳转到字母 {letter}"],
    "From currency: {code}, {name}": ["मूल मुद्रा: {code}, {name}", "اصل کرنسی: {code}، {name}", "Moneda de origen: {code}, {name}", "Devise source : {code}, {name}", "Ausgangswährung: {code}, {name}", "عملة المصدر: {code}، {name}", "源货币：{code}，{name}"],
    "To currency: {code}, {name}": ["लक्ष्य मुद्रा: {code}, {name}", "مطلوبہ کرنسی: {code}، {name}", "Moneda de destino: {code}, {name}", "Devise cible : {code}, {name}", "Zielwährung: {code}, {name}", "عملة الوجهة: {code}، {name}", "目标货币：{code}，{name}"],
    "Classic Indigo (#45539a)": ["क्लासिक इंडिगो (#45539a)", "کلاسک انڈیگو (#45539a)", "Índigo clásico (#45539a)", "Indigo classique (#45539a)", "Klassisches Indigo (#45539a)", "نيلي كلاسيكي (#45539a)", "经典靛蓝（#45539a）"],
    "Deep Amber (#e65100)": ["गहरा एम्बर (#e65100)", "گہرا عنبری (#e65100)", "Ámbar intenso (#e65100)", "Ambre profond (#e65100)", "Tiefes Amber (#e65100)", "كهرماني داكن (#e65100)", "深琥珀色（#e65100）"],
  });

  // Dynamic tool labels, empty states, result accessibility and currency status.
  Object.assign(rows, {
    "Underweight": ["कम वज़न", "کم وزن", "Bajo peso", "Insuffisance pondérale", "Untergewicht", "نقص الوزن", "体重过轻"],
    "Normal Weight": ["सामान्य वज़न", "عام وزن", "Peso normal", "Poids normal", "Normalgewicht", "وزن طبيعي", "正常体重"],
    "Overweight": ["अधिक वज़न", "زیادہ وزن", "Sobrepeso", "Surpoids", "Übergewicht", "زيادة الوزن", "超重"],
    "Obese": ["मोटापा", "موٹاپا", "Obesidad", "Obésité", "Adipositas", "السمنة", "肥胖"],
    "Select gender": ["लिंग चुनें", "جنس منتخب کریں", "Selecciona el sexo", "Sélectionnez le genre", "Geschlecht auswählen", "اختر الجنس", "选择性别"],
    "No matching time zones": ["कोई मेल खाता समय क्षेत्र नहीं मिला", "کوئی مماثل ٹائم زون نہیں ملا", "No se encontraron zonas horarias", "Aucun fuseau horaire correspondant", "Keine passende Zeitzone gefunden", "لم يتم العثور على مناطق زمنية مطابقة", "未找到匹配的时区"],
    "No cities added yet. Search above to add a world clock.": ["अभी कोई शहर नहीं जोड़ा गया है। विश्व घड़ी जोड़ने के लिए ऊपर खोजें।", "ابھی کوئی شہر شامل نہیں کیا گیا۔ عالمی گھڑی شامل کرنے کے لیے اوپر تلاش کریں۔", "Aún no hay ciudades. Busca arriba para añadir un reloj mundial.", "Aucune ville ajoutée. Recherchez ci-dessus pour ajouter une horloge mondiale.", "Noch keine Städte hinzugefügt. Suchen Sie oben, um eine Weltzeituhr hinzuzufügen.", "لم تتم إضافة مدن بعد. ابحث أعلاه لإضافة ساعة عالمية.", "尚未添加城市。请在上方搜索以添加世界时钟。"],
    "Enter text": ["टेक्स्ट दर्ज करें", "متن درج کریں", "Introducir texto", "Saisir le texte", "Text eingeben", "أدخل النص", "输入文本"],
    "Name": ["नाम", "نام", "Nombre", "Nom", "Name", "الاسم", "名称"],
    "Calculation": ["गणना", "حساب", "Cálculo", "Calcul", "Berechnung", "عملية حسابية", "计算"],
    "Choose an option": ["एक विकल्प चुनें", "ایک اختیار منتخب کریں", "Elige una opción", "Choisissez une option", "Option auswählen", "اختر خيارًا", "选择一个选项"],
    "Subject name": ["विषय का नाम", "مضمون کا نام", "Nombre de la asignatura", "Nom de la matière", "Fachname", "اسم المادة", "科目名称"],
    "Remove subject": ["विषय हटाएँ", "مضمون ہٹائیں", "Eliminar asignatura", "Supprimer la matière", "Fach entfernen", "إزالة المادة", "删除科目"],
    "Live preview": ["लाइव पूर्वावलोकन", "لائیو پیش منظر", "Vista previa en vivo", "Aperçu en direct", "Live-Vorschau", "معاينة مباشرة", "实时预览"],
    "Calculation error": ["गणना त्रुटि", "حساب کی خرابی", "Error de cálculo", "Erreur de calcul", "Berechnungsfehler", "خطأ في الحساب", "计算错误"],
    "Memory empty": ["मेमोरी खाली है", "میموری خالی ہے", "Memoria vacía", "Mémoire vide", "Speicher leer", "الذاكرة فارغة", "存储器为空"],
    "From unit: {name}": ["स्रोत इकाई: {name}", "ماخذ اکائی: {name}", "Unidad de origen: {name}", "Unité source : {name}", "Ausgangseinheit: {name}", "وحدة المصدر: {name}", "源单位：{name}"],
    "To unit: {name}": ["लक्ष्य इकाई: {name}", "منزل اکائی: {name}", "Unidad de destino: {name}", "Unité cible : {name}", "Zieleinheit: {name}", "وحدة الهدف: {name}", "目标单位：{name}"],
    "From: {name}": ["से: {name}", "من: {name}", "Desde: {name}", "De : {name}", "Von: {name}", "من: {name}", "从：{name}"],
    "To: {name}": ["तक: {name}", "کو: {name}", "Hasta: {name}", "Vers : {name}", "Nach: {name}", "إلى: {name}", "到：{name}"],
    "Delete {title}": ["{title} हटाएँ", "حذف کریں: {title}", "Eliminar {title}", "Supprimer {title}", "{title} löschen", "حذف {title}", "删除 {title}"],
    "Calculation value: {value}": ["गणना मान: {value}", "حساب کی قدر: {value}", "Valor del cálculo: {value}", "Valeur du calcul : {value}", "Berechnungswert: {value}", "قيمة الحساب: {value}", "计算值：{value}"],
    "Calculation result: {value}": ["गणना परिणाम: {value}", "حساب کا نتیجہ: {value}", "Resultado del cálculo: {value}", "Résultat du calcul : {value}", "Berechnungsergebnis: {value}", "نتيجة الحساب: {value}", "计算结果：{value}"],
    "Live preview: {value}": ["लाइव पूर्वावलोकन: {value}", "لائیو پیش منظر: {value}", "Vista previa en vivo: {value}", "Aperçu en direct : {value}", "Live-Vorschau: {value}", "معاينة مباشرة: {value}", "实时预览：{value}"],
    "Angle mode {unit}": ["कोण मोड {unit}", "زاویہ موڈ {unit}", "Modo angular {unit}", "Mode angulaire {unit}", "Winkelmodus {unit}", "وضع الزاوية {unit}", "角度模式 {unit}"],
    "Memory contains {value}": ["मेमोरी में {value} है", "میموری میں {value} موجود ہے", "La memoria contiene {value}", "La mémoire contient {value}", "Speicher enthält {value}", "تحتوي الذاكرة على {value}", "存储器包含 {value}"],
    "Offline · last known rates only": ["ऑफ़लाइन · केवल पिछली ज्ञात दरें", "آف لائن · صرف آخری معلوم شرحیں", "Sin conexión · solo últimos tipos conocidos", "Hors ligne · derniers taux connus uniquement", "Offline · nur zuletzt bekannte Kurse", "غير متصل · آخر الأسعار المعروفة فقط", "离线 · 仅显示上次已知汇率"],
    "Cached reference rates · live refresh unavailable": ["कैश की गई संदर्भ दरें · लाइव अपडेट उपलब्ध नहीं", "کیش شدہ حوالہ شرحیں · لائیو اپ ڈیٹ دستیاب نہیں", "Tipos de referencia en caché · actualización en vivo no disponible", "Taux de référence en cache · actualisation en direct indisponible", "Zwischengespeicherte Referenzkurse · Live-Aktualisierung nicht verfügbar", "أسعار مرجعية مخزنة مؤقتًا · التحديث المباشر غير متاح", "缓存参考汇率 · 无法实时刷新"],
    "Built-in estimate rates · live refresh unavailable": ["अंतर्निहित अनुमानित दरें · लाइव अपडेट उपलब्ध नहीं", "بلٹ اِن تخمینی شرحیں · لائیو اپ ڈیٹ دستیاب نہیں", "Tipos estimados integrados · actualización en vivo no disponible", "Taux estimés intégrés · actualisation en direct indisponible", "Integrierte Schätzkurse · Live-Aktualisierung nicht verfügbar", "أسعار تقديرية مدمجة · التحديث المباشر غير متاح", "内置估算汇率 · 无法实时刷新"],
    "Network required for current rates": ["वर्तमान दरों के लिए नेटवर्क आवश्यक है", "موجودہ شرحوں کے لیے نیٹ ورک درکار ہے", "Se necesita conexión para obtener los tipos actuales", "Une connexion est nécessaire pour obtenir les taux actuels", "Für aktuelle Kurse ist eine Netzwerkverbindung erforderlich", "يلزم الاتصال بالشبكة للحصول على الأسعار الحالية", "获取当前汇率需要网络连接"],
    "Live rate unavailable · retry scheduled": ["लाइव दर उपलब्ध नहीं · पुनः प्रयास निर्धारित", "لائیو شرح دستیاب نہیں · دوبارہ کوشش مقرر", "Tipo en vivo no disponible · reintento programado", "Taux en direct indisponible · nouvelle tentative programmée", "Live-Kurs nicht verfügbar · erneuter Versuch geplant", "السعر المباشر غير متاح · تمت جدولة إعادة المحاولة", "实时汇率不可用 · 已安排重试"],
    "Live rate unavailable for selected currency": ["चुनी गई मुद्रा के लिए लाइव दर उपलब्ध नहीं", "منتخب کرنسی کے لیے لائیو شرح دستیاب نہیں", "Tipo en vivo no disponible para la moneda seleccionada", "Taux en direct indisponible pour la devise sélectionnée", "Live-Kurs für die ausgewählte Währung nicht verfügbar", "السعر المباشر غير متاح للعملة المحددة", "所选货币暂无实时汇率"],
  });

  // Remaining direction, currency and angle labels.
  Object.assign(rows, {
    "Degrees": ["डिग्री", "ڈگری", "Grados", "Degrés", "Grad", "درجات", "度"],
    "Radians": ["रेडियन", "ریڈین", "Radianes", "Radians", "Radiant", "راديان", "弧度"],
    "From currency: {code}": ["मूल मुद्रा: {code}", "اصل کرنسی: {code}", "Moneda de origen: {code}", "Devise source : {code}", "Ausgangswährung: {code}", "عملة المصدر: {code}", "源货币：{code}"],
    "To currency: {code}": ["लक्ष्य मुद्रा: {code}", "مطلوبہ کرنسی: {code}", "Moneda de destino: {code}", "Devise cible : {code}", "Zielwährung: {code}", "عملة الوجهة: {code}", "目标货币：{code}"],
  });
  Object.assign(rows, {
    'Edit date': ['तारीख संपादित करें','تاریخ میں ترمیم کریں','Editar fecha','Modifier la date','Datum bearbeiten','تعديل التاريخ','编辑日期'],
  });

  Object.assign(rows, {
    "Last checked: {checked} · Rates last updated: {updated}. Times are shown in your device's local time.": ["अंतिम जाँच: {checked} · दरें अपडेट: {updated}। समय आपके डिवाइस के स्थानीय समय के अनुसार दिखाया जाता है।", "آخری جانچ: {checked} · شرحیں اپ ڈیٹ: {updated}۔ اوقات آپ کے آلے کے مقامی وقت کے مطابق دکھائے جاتے ہیں۔", "Última comprobación: {checked} · Tipos actualizados: {updated}. Las horas se muestran según la hora local de tu dispositivo.", "Dernière vérification : {checked} · Taux mis à jour : {updated}. Les heures sont affichées selon l’heure locale de votre appareil.", "Zuletzt geprüft: {checked} · Kurse aktualisiert: {updated}. Zeiten werden in der Ortszeit Ihres Geräts angezeigt.", "آخر تحقق: {checked} · آخر تحديث للأسعار: {updated}. تُعرض الأوقات وفق التوقيت المحلي لجهازك.", "上次检查：{checked} · 汇率更新：{updated}。时间按您设备的本地时间显示。"],
  });

  // Unit Converter names: localized labels preserve their canonical symbols/codes.
  Object.assign(rows, {
    "Acre (ac)": ["एकड़ (ac)", "ایکڑ (ac)", "Acre (ac)", "Acre (ac)", "Acre (ac)", "فدان (ac)", "英亩（ac）"],
    "Atmosphere (atm)": ["वायुमंडल (atm)", "فضا (atm)", "Atmósfera (atm)", "Atmosphère (atm)", "Atmosphäre (atm)", "ضغط جوي (atm)", "标准大气压（atm）"],
    "Bar (bar)": ["बार (bar)", "بار (bar)", "Bar (bar)", "Bar (bar)", "Bar (bar)", "بار (bar)", "巴（bar）"],
    "Bit (bit)": ["बिट (bit)", "بٹ (bit)", "Bit (bit)", "Bit (bit)", "Bit (bit)", "بت (bit)", "比特（bit）"],
    "Byte (B)": ["बाइट (B)", "بائٹ (B)", "Byte (B)", "Octet (B)", "Byte (B)", "بايت (B)", "字节（B）"],
    "Calorie (cal)": ["कैलोरी (cal)", "کیلوری (cal)", "Caloría (cal)", "Calorie (cal)", "Kalorie (cal)", "سعرة حرارية (cal)", "卡路里（cal）"],
    "Celsius (°C)": ["सेल्सियस (°C)", "سیلسیس (°C)", "Celsius (°C)", "Celsius (°C)", "Celsius (°C)", "مئوية (°C)", "摄氏度（°C）"],
    "Centimeter (cm)": ["सेंटीमीटर (cm)", "سینٹی میٹر (cm)", "Centímetro (cm)", "Centimètre (cm)", "Zentimeter (cm)", "سنتيمتر (cm)", "厘米（cm）"],
    "Cubic centimeter (cm³)": ["घन सेंटीमीटर (cm³)", "مکعب سینٹی میٹر (cm³)", "Centímetro cúbico (cm³)", "Centimètre cube (cm³)", "Kubikzentimeter (cm³)", "سنتيمتر مكعب (cm³)", "立方厘米（cm³）"],
    "Cubic meter (m³)": ["घन मीटर (m³)", "مکعب میٹر (m³)", "Metro cúbico (m³)", "Mètre cube (m³)", "Kubikmeter (m³)", "متر مكعب (m³)", "立方米（m³）"],
    "Day (d)": ["दिन (d)", "دن (d)", "Día (d)", "Jour (d)", "Tag (d)", "يوم (d)", "天（d）"],
    "Fahrenheit (°F)": ["फ़ारेनहाइट (°F)", "فارن ہائیٹ (°F)", "Fahrenheit (°F)", "Fahrenheit (°F)", "Fahrenheit (°F)", "فهرنهايت (°F)", "华氏度（°F）"],
    "Foot (ft)": ["फुट (ft)", "فٹ (ft)", "Pie (ft)", "Pied (ft)", "Fuß (ft)", "قدم (ft)", "英尺（ft）"],
    "Gigabyte (GB)": ["गीगाबाइट (GB)", "گیگا بائٹ (GB)", "Gigabyte (GB)", "Gigaoctet (GB)", "Gigabyte (GB)", "غيغابايت (GB)", "吉字节（GB）"],
    "Gram (g)": ["ग्राम (g)", "گرام (g)", "Gramo (g)", "Gramme (g)", "Gramm (g)", "غرام (g)", "克（g）"],
    "Hectare (ha)": ["हेक्टेयर (ha)", "ہیکٹر (ha)", "Hectárea (ha)", "Hectare (ha)", "Hektar (ha)", "هكتار (ha)", "公顷（ha）"],
    "Hectopascal (hPa)": ["हेक्टोपास्कल (hPa)", "ہیکٹو پاسکل (hPa)", "Hectopascal (hPa)", "Hectopascal (hPa)", "Hektopascal (hPa)", "هيكتوباسكال (hPa)", "百帕（hPa）"],
    "Horsepower (HP)": ["हॉर्सपावर (HP)", "ہارس پاور (HP)", "Caballo de fuerza (HP)", "Cheval-vapeur (HP)", "Pferdestärke (HP)", "حصان بخاري (HP)", "马力（HP）"],
    "Hour (h)": ["घंटा (h)", "گھنٹہ (h)", "Hora (h)", "Heure (h)", "Stunde (h)", "ساعة (h)", "小时（h）"],
    "Imperial gallon (Imp gal)": ["इंपीरियल गैलन (Imp gal)", "امپیریل گیلن (Imp gal)", "Galón imperial (Imp gal)", "Gallon impérial (Imp gal)", "Imperiale Gallone (Imp gal)", "غالون إمبراطوري (Imp gal)", "英制加仑（Imp gal）"],
    "Inch (in)": ["इंच (in)", "انچ (in)", "Pulgada (in)", "Pouce (in)", "Zoll (in)", "بوصة (in)", "英寸（in）"],
    "Joule (J)": ["जूल (J)", "جول (J)", "Julio (J)", "Joule (J)", "Joule (J)", "جول (J)", "焦耳（J）"],
    "Kelvin (K)": ["केल्विन (K)", "کیلون (K)", "Kelvin (K)", "Kelvin (K)", "Kelvin (K)", "كلفن (K)", "开尔文（K）"],
    "Kilobyte (KB)": ["किलोबाइट (KB)", "کلو بائٹ (KB)", "Kilobyte (KB)", "Kilooctet (KB)", "Kilobyte (KB)", "كيلوبايت (KB)", "千字节（KB）"],
    "Kilocalorie (kcal)": ["किलोकैलोरी (kcal)", "کلو کیلوری (kcal)", "Kilocaloría (kcal)", "Kilocalorie (kcal)", "Kilokalorie (kcal)", "كيلو سعرة حرارية (kcal)", "千卡（kcal）"],
    "Kilogram (kg)": ["किलोग्राम (kg)", "کلوگرام (kg)", "Kilogramo (kg)", "Kilogramme (kg)", "Kilogramm (kg)", "كيلوغرام (kg)", "千克（kg）"],
    "Kilojoule (kJ)": ["किलोजूल (kJ)", "کلو جول (kJ)", "Kilojulio (kJ)", "Kilojoule (kJ)", "Kilojoule (kJ)", "كيلوجول (kJ)", "千焦（kJ）"],
    "Kilometer (km)": ["किलोमीटर (km)", "کلومیٹر (km)", "Kilómetro (km)", "Kilomètre (km)", "Kilometer (km)", "كيلومتر (km)", "千米（km）"],
    "Kilometers per liter (km/L)": ["किलोमीटर प्रति लीटर (km/L)", "کلومیٹر فی لیٹر (km/L)", "Kilómetros por litro (km/L)", "Kilomètres par litre (km/L)", "Kilometer pro Liter (km/L)", "كيلومتر لكل لتر (km/L)", "公里/升（km/L）"],
    "Kilopascal (kPa)": ["किलोपास्कल (kPa)", "کلو پاسکل (kPa)", "Kilopascal (kPa)", "Kilopascal (kPa)", "Kilopascal (kPa)", "كيلوباسكال (kPa)", "千帕（kPa）"],
    "Kilowatt (kW)": ["किलोवाट (kW)", "کلو واٹ (kW)", "Kilovatio (kW)", "Kilowatt (kW)", "Kilowatt (kW)", "كيلوواط (kW)", "千瓦（kW）"],
    "Kilowatt hour (kWh)": ["किलोवाट घंटा (kWh)", "کلو واٹ گھنٹہ (kWh)", "Kilovatio hora (kWh)", "Kilowattheure (kWh)", "Kilowattstunde (kWh)", "كيلوواط ساعة (kWh)", "千瓦时（kWh）"],
    "Knot (kn)": ["नॉट (kn)", "ناٹ (kn)", "Nudo (kn)", "Nœud (kn)", "Knoten (kn)", "عقدة (kn)", "节（kn）"],
    "Liter (L)": ["लीटर (L)", "لیٹر (L)", "Litro (L)", "Litre (L)", "Liter (L)", "لتر (L)", "升（L）"],
    "Liters per 100 km (L/100 km)": ["लीटर प्रति 100 किमी (L/100 km)", "لیٹر فی 100 کلومیٹر (L/100 km)", "Litros por 100 km (L/100 km)", "Litres aux 100 km (L/100 km)", "Liter pro 100 km (L/100 km)", "لتر لكل 100 كم (L/100 km)", "升/百公里（L/100 km）"],
    "Megabyte (MB)": ["मेगाबाइट (MB)", "میگا بائٹ (MB)", "Megabyte (MB)", "Mégaoctet (MB)", "Megabyte (MB)", "ميغابايت (MB)", "兆字节（MB）"],
    "Megawatt (MW)": ["मेगावाट (MW)", "میگا واٹ (MW)", "Megavatio (MW)", "Mégawatt (MW)", "Megawatt (MW)", "ميغاواط (MW)", "兆瓦（MW）"],
    "Meter (m)": ["मीटर (m)", "میٹر (m)", "Metro (m)", "Mètre (m)", "Meter (m)", "متر (m)", "米（m）"],
    "Metric ton (t)": ["मीट्रिक टन (t)", "میٹرک ٹن (t)", "Tonelada métrica (t)", "Tonne métrique (t)", "Metrische Tonne (t)", "طن متري (t)", "公吨（t）"],
    "Mile (mi)": ["मील (mi)", "میل (mi)", "Milla (mi)", "Mile (mi)", "Meile (mi)", "ميل (mi)", "英里（mi）"],
    "Miles per Imperial gallon (mpg UK)": ["मील प्रति इंपीरियल गैलन (mpg UK)", "میل فی امپیریل گیلن (mpg UK)", "Millas por galón imperial (mpg UK)", "Milles par gallon impérial (mpg UK)", "Meilen pro imperialer Gallone (mpg UK)", "ميل لكل غالون إمبراطوري (mpg UK)", "英里/英制加仑（mpg UK）"],
    "Miles per US gallon (mpg US)": ["मील प्रति US गैलन (mpg US)", "میل فی امریکی گیلن (mpg US)", "Millas por galón estadounidense (mpg US)", "Milles par gallon américain (mpg US)", "Meilen pro US-Gallone (mpg US)", "ميل لكل غالون أمريكي (mpg US)", "英里/美制加仑（mpg US）"],
    "Milligram (mg)": ["मिलीग्राम (mg)", "ملی گرام (mg)", "Miligramo (mg)", "Milligramme (mg)", "Milligramm (mg)", "مليغرام (mg)", "毫克（mg）"],
    "Milliliter (mL)": ["मिलीलीटर (mL)", "ملی لیٹر (mL)", "Mililitro (mL)", "Millilitre (mL)", "Milliliter (mL)", "مليلتر (mL)", "毫升（mL）"],
    "Millimeter (mm)": ["मिलीमीटर (mm)", "ملی میٹر (mm)", "Milímetro (mm)", "Millimètre (mm)", "Millimeter (mm)", "مليمتر (mm)", "毫米（mm）"],
    "Millisecond (ms)": ["मिलीसेकंड (ms)", "ملی سیکنڈ (ms)", "Milisegundo (ms)", "Milliseconde (ms)", "Millisekunde (ms)", "مللي ثانية (ms)", "毫秒（ms）"],
    "Minute (min)": ["मिनट (min)", "منٹ (min)", "Minuto (min)", "Minute (min)", "Minute (min)", "دقيقة (min)", "分钟（min）"],
    "Nautical mile": ["समुद्री मील", "سمندری میل", "Milla náutica", "Mille nautique", "Seemeile", "ميل بحري", "海里"],
    "Ounce (oz)": ["औंस (oz)", "اونس (oz)", "Onza (oz)", "Once (oz)", "Unze (oz)", "أونصة (oz)", "盎司（oz）"],
    "PSI (psi)": ["PSI (psi)", "PSI (psi)", "PSI (psi)", "PSI (psi)", "PSI (psi)", "رطل لكل بوصة مربعة (psi)", "磅/平方英寸（psi）"],
    "Pascal (Pa)": ["पास्कल (Pa)", "پاسکل (Pa)", "Pascal (Pa)", "Pascal (Pa)", "Pascal (Pa)", "باسكال (Pa)", "帕斯卡（Pa）"],
    "Petabyte (PB)": ["पेटाबाइट (PB)", "پیٹا بائٹ (PB)", "Petabyte (PB)", "Pétaoctet (PB)", "Petabyte (PB)", "بيتابايت (PB)", "拍字节（PB）"],
    "Pound (lb)": ["पाउंड (lb)", "پاؤنڈ (lb)", "Libra (lb)", "Livre (lb)", "Pfund (lb)", "رطل (lb)", "磅（lb）"],
    "Second (s)": ["सेकंड (s)", "سیکنڈ (s)", "Segundo (s)", "Seconde (s)", "Sekunde (s)", "ثانية (s)", "秒（s）"],
    "Square centimeter (cm²)": ["वर्ग सेंटीमीटर (cm²)", "مربع سینٹی میٹر (cm²)", "Centímetro cuadrado (cm²)", "Centimètre carré (cm²)", "Quadratzentimeter (cm²)", "سنتيمتر مربع (cm²)", "平方厘米（cm²）"],
    "Square foot (ft²)": ["वर्ग फुट (ft²)", "مربع فٹ (ft²)", "Pie cuadrado (ft²)", "Pied carré (ft²)", "Quadratfuß (ft²)", "قدم مربع (ft²)", "平方英尺（ft²）"],
    "Square inch (in²)": ["वर्ग इंच (in²)", "مربع انچ (in²)", "Pulgada cuadrada (in²)", "Pouce carré (in²)", "Quadratzoll (in²)", "بوصة مربعة (in²)", "平方英寸（in²）"],
    "Square kilometer (km²)": ["वर्ग किलोमीटर (km²)", "مربع کلومیٹر (km²)", "Kilómetro cuadrado (km²)", "Kilomètre carré (km²)", "Quadratkilometer (km²)", "كيلومتر مربع (km²)", "平方公里（km²）"],
    "Square meter (m²)": ["वर्ग मीटर (m²)", "مربع میٹر (m²)", "Metro cuadrado (m²)", "Mètre carré (m²)", "Quadratmeter (m²)", "متر مربع (m²)", "平方米（m²）"],
    "Square millimeter (mm²)": ["वर्ग मिलीमीटर (mm²)", "مربع ملی میٹر (mm²)", "Milímetro cuadrado (mm²)", "Millimètre carré (mm²)", "Quadratmillimeter (mm²)", "مليمتر مربع (mm²)", "平方毫米（mm²）"],
    "Square yard (yd²)": ["वर्ग गज (yd²)", "مربع گز (yd²)", "Yarda cuadrada (yd²)", "Yard carré (yd²)", "Quadratyard (yd²)", "ياردة مربعة (yd²)", "平方码（yd²）"],
    "Stone (st)": ["स्टोन (st)", "اسٹون (st)", "Stone (st)", "Stone (st)", "Stone (st)", "ستون (st)", "英石（st）"],
    "Terabyte (TB)": ["टेराबाइट (TB)", "ٹیرا بائٹ (TB)", "Terabyte (TB)", "Téraoctet (TB)", "Terabyte (TB)", "تيرابايت (TB)", "太字节（TB）"],
    "US cup": ["अमेरिकी कप", "امریکی کپ", "Taza estadounidense", "Tasse américaine", "US-Tasse", "كوب أمريكي", "美制杯"],
    "US fluid ounce (fl oz)": ["अमेरिकी द्रव औंस (fl oz)", "امریکی فلوئڈ اونس (fl oz)", "Onza líquida estadounidense (fl oz)", "Once liquide américaine (fl oz)", "US-Flüssigunze (fl oz)", "أونصة سائلة أمريكية (fl oz)", "美制液量盎司（fl oz）"],
    "US gallon (gal)": ["अमेरिकी गैलन (gal)", "امریکی گیلن (gal)", "Galón estadounidense (gal)", "Gallon américain (gal)", "US-Gallone (gal)", "غالون أمريكي (gal)", "美制加仑（gal）"],
    "US pint (pt)": ["अमेरिकी पिंट (pt)", "امریکی پنٹ (pt)", "Pinta estadounidense (pt)", "Pinte américaine (pt)", "US-Pint (pt)", "باينت أمريكي (pt)", "美制品脱（pt）"],
    "Watt (W)": ["वाट (W)", "واٹ (W)", "Vatio (W)", "Watt (W)", "Watt (W)", "واط (W)", "瓦（W）"],
    "Watt hour (Wh)": ["वाट घंटा (Wh)", "واٹ گھنٹہ (Wh)", "Vatio-hora (Wh)", "Wattheure (Wh)", "Wattstunde (Wh)", "واط ساعة (Wh)", "瓦时（Wh）"],
    "Week (wk)": ["सप्ताह (wk)", "ہفتہ (wk)", "Semana (wk)", "Semaine (wk)", "Woche (wk)", "أسبوع (wk)", "周（wk）"],
    "Yard (yd)": ["गज (yd)", "گز (yd)", "Yarda (yd)", "Yard (yd)", "Yard (yd)", "ياردة (yd)", "码（yd）"],
    "Year (365 d)": ["वर्ष (365 d)", "سال (365 d)", "Año (365 d)", "Année (365 d)", "Jahr (365 d)", "سنة (365 d)", "年（365 d）"],
    "km/h": ["किमी/घंटा", "کلومیٹر فی گھنٹہ", "km/h", "km/h", "km/h", "كم/ساعة", "公里/小时"],
    "m/s": ["मीटर/सेकंड", "میٹر فی سیکنڈ", "m/s", "m/s", "m/s", "متر/ثانية", "米/秒"],
    "mmHg": ["mmHg", "mmHg", "mmHg", "mmHg", "mmHg", "ملليمتر زئبق", "毫米汞柱"],
    "mph": ["मील/घंटा", "میل فی گھنٹہ", "mph", "mph", "mph", "ميل/ساعة", "英里/小时"],
  });

  Object.assign(rows, {
    "YOUR CALCULATION WORKSPACE": ["आपका गणना कार्यक्षेत्र", "آپ کا حسابی ورک اسپیس", "TU ESPACIO DE CÁLCULO", "VOTRE ESPACE DE CALCUL", "IHR RECHNER-ARBEITSBEREICH", "مساحة الحساب الخاصة بك", "您的计算工作区"],
  });

  // Remaining unit, financial validation, calendar and provider status strings.
  Object.assign(rows, {
    "Check principal, annual rate (0–1000%), period (1–1200 months), and grace months.": ["मूलधन, वार्षिक दर (0–1000%), अवधि (1–1200 महीने) और छूट अवधि जाँचें।", "اصل رقم، سالانہ شرح (0–1000%)، مدت (1–1200 ماہ) اور رعایتی مدت چیک کریں۔", "Comprueba el capital, la tasa anual (0–1000%), el plazo (1–1200 meses) y los meses de gracia.", "Vérifiez le capital, le taux annuel (0–1000 %), la durée (1–1200 mois) et les mois de différé.", "Prüfen Sie Kapital, Jahreszins (0–1000 %), Laufzeit (1–1200 Monate) und tilgungsfreie Monate.", "تحقق من أصل القرض والمعدل السنوي (0–1000%) والمدة (1–1200 شهرًا) وأشهر السماح.", "检查本金、年利率（0–1000%）、期限（1–1200 个月）和宽限月数。"],
    "Choose a valid category": ["मान्य श्रेणी चुनें", "درست زمرہ منتخب کریں", "Elige una categoría válida", "Choisissez une catégorie valide", "Wählen Sie eine gültige Kategorie", "اختر فئة صالحة", "请选择有效类别"],
    "Choose valid units": ["मान्य इकाइयाँ चुनें", "درست اکائیاں منتخب کریں", "Elige unidades válidas", "Choisissez des unités valides", "Wählen Sie gültige Einheiten", "اختر وحدات صالحة", "请选择有效单位"],
    "Conversion is undefined for this value": ["इस मान के लिए रूपांतरण परिभाषित नहीं है", "اس قدر کے لیے تبدیلی متعین نہیں", "La conversión no está definida para este valor", "La conversion n’est pas définie pour cette valeur", "Für diesen Wert ist keine Umrechnung definiert", "التحويل غير معرّف لهذه القيمة", "此数值未定义转换"],
    "Enter valid data": ["मान्य डेटा दर्ज करें", "درست ڈیٹا درج کریں", "Introduce datos válidos", "Saisissez des données valides", "Gültige Daten eingeben", "أدخل بيانات صالحة", "请输入有效数据"],
    "Please enter valid data": ["कृपया मान्य डेटा दर्ज करें", "براہ کرم درست ڈیٹا درج کریں", "Introduce datos válidos", "Veuillez saisir des données valides", "Bitte gültige Daten eingeben", "يرجى إدخال بيانات صالحة", "请输入有效数据"],
    "Every year · {date}": ["हर साल · {date}", "ہر سال · {date}", "Cada año · {date}", "Chaque année · {date}", "Jedes Jahr · {date}", "كل عام · {date}", "每年 · {date}"],
    "Selected currency pair not provided by {source}": ["चुनी गई मुद्रा जोड़ी {source} द्वारा उपलब्ध नहीं कराई गई", "منتخب کرنسی جوڑا {source} فراہم نہیں کرتا", "El par de monedas seleccionado no está disponible en {source}", "La paire de devises sélectionnée n’est pas fournie par {source}", "Das ausgewählte Währungspaar wird von {source} nicht bereitgestellt", "زوج العملات المحدد غير متاح لدى {source}", "所选货币对未由 {source} 提供"],
    "Reference rates updated · {source}": ["संदर्भ दरें अपडेट · {source}", "حوالہ جاتی شرحیں اپ ڈیٹ · {source}", "Tipos de referencia actualizados · {source}", "Taux de référence mis à jour · {source}", "Referenzkurse aktualisiert · {source}", "تم تحديث الأسعار المرجعية · {source}", "参考汇率已更新 · {source}"],
    "* 1 {from} = Rate unavailable for {to}": ["* 1 {from} = {to} की दर उपलब्ध नहीं", "* 1 {from} = {to} کی شرح دستیاب نہیں", "* 1 {from} = tipo no disponible para {to}", "* 1 {from} = taux indisponible pour {to}", "* 1 {from} = Kurs für {to} nicht verfügbar", "* 1 {from} = السعر غير متاح لـ {to}", "* 1 {from} = 暂无 {to} 汇率"],
    "rate date {date}": ["दर की तारीख {date}", "شرح کی تاریخ {date}", "fecha del tipo {date}", "date du taux {date}", "Kursdatum {date}", "تاريخ السعر {date}", "汇率日期 {date}"],
  });

  Object.assign(rows, {
    "* 1 {from} = {rate} {to} · rate date {date}": ["* 1 {from} = {rate} {to} · दर की तारीख {date}", "* 1 {from} = {rate} {to} · شرح کی تاریخ {date}", "* 1 {from} = {rate} {to} · fecha del tipo {date}", "* 1 {from} = {rate} {to} · date du taux {date}", "* 1 {from} = {rate} {to} · Kursdatum {date}", "* 1 {from} = {rate} {to} · تاريخ السعر {date}", "* 1 {from} = {rate} {to} · 汇率日期 {date}"],
    "Reference rates updated · {source} · unavailable: {missing} (retry scheduled)": ["संदर्भ दरें अपडेट · {source} · अनुपलब्ध: {missing} (पुनः प्रयास निर्धारित)", "حوالہ جاتی شرحیں اپ ڈیٹ · {source} · دستیاب نہیں: {missing} (دوبارہ کوشش مقرر)", "Tipos de referencia actualizados · {source} · no disponibles: {missing} (reintento programado)", "Taux de référence mis à jour · {source} · indisponibles : {missing} (nouvelle tentative programmée)", "Referenzkurse aktualisiert · {source} · nicht verfügbar: {missing} (erneuter Versuch geplant)", "تم تحديث الأسعار المرجعية · {source} · غير متاحة: {missing} (تمت جدولة إعادة المحاولة)", "参考汇率已更新 · {source} · 不可用：{missing}（已安排重试）"],
  });

  // Dynamic loan schedule and unit-price comparison messages.
  Object.assign(rows, {
    "Item {item} (Lowest unit price)": ["वस्तु {item} (सबसे कम इकाई मूल्य)", "آئٹم {item} (سب سے کم فی یونٹ قیمت)", "Artículo {item} (menor precio unitario)", "Article {item} (prix unitaire le plus bas)", "Artikel {item} (niedrigster Stückpreis)", "العنصر {item} (أقل سعر للوحدة)", "项目 {item}（单位价格最低）"],
    "Items {items} (Equal lowest unit price)": ["वस्तुएँ {items} (समान सबसे कम इकाई मूल्य)", "آئٹمز {items} (یکساں کم ترین فی یونٹ قیمت)", "Artículos {items} (mismo precio unitario mínimo)", "Articles {items} (même prix unitaire le plus bas)", "Artikel {items} (gleicher niedrigster Stückpreis)", "العناصر {items} (أقل سعر متساوٍ للوحدة)", "项目 {items}（单位最低价并列）"],
    "{months} monthly payments · {grace} interest-only months · Equal principal": ["{months} मासिक भुगतान · {grace} केवल-ब्याज महीने · समान मूलधन", "{months} ماہانہ ادائیگیاں · {grace} صرف سود کے ماہ · یکساں اصل زر", "{months} pagos mensuales · {grace} meses solo de intereses · capital constante", "{months} paiements mensuels · {grace} mois d’intérêts seuls · capital constant", "{months} Monatszahlungen · {grace} reine Zinsmonate · gleiche Tilgung", "{months} دفعات شهرية · {grace} أشهر فائدة فقط · أصل دين متساوٍ", "{months} 期月供 · {grace} 期只付利息 · 等额本金"],
    "{months} monthly payments · {grace} interest-only months · Equal total payment": ["{months} मासिक भुगतान · {grace} केवल-ब्याज महीने · समान कुल भुगतान", "{months} ماہانہ ادائیگیاں · {grace} صرف سود کے ماہ · یکساں کل ادائیگی", "{months} pagos mensuales · {grace} meses solo de intereses · cuota total constante", "{months} paiements mensuels · {grace} mois d’intérêts seuls · paiement total constant", "{months} Monatszahlungen · {grace} reine Zinsmonate · gleichbleibende Gesamtzahlung", "{months} دفعات شهرية · {grace} أشهر فائدة فقط · إجمالي دفعة متساوٍ", "{months} 期月供 · {grace} 期只付利息 · 等额本息"],
  });

  Object.assign(rows, {
    "Small": ["छोटा", "چھوٹا", "Pequeño", "Petit", "Klein", "صغير", "小"],
    "Medium": ["मध्यम", "درمیانہ", "Mediano", "Moyen", "Mittel", "متوسط", "中"],
    "Large": ["बड़ा", "بڑا", "Grande", "Grand", "Groß", "كبير", "大"],
    "Heavy": ["भारी", "بھاری", "Pesado", "Lourd", "Schwer", "ثقيل", "重"],
  });
  const langs = ['hi','ur','es','fr','de','ar','zh'];
  const dictionaries = Object.fromEntries(langs.map((lang, index) => [lang, Object.fromEntries(Object.entries(rows).map(([en, translations]) => [en, translations[index]]))]));
  const originals = new WeakMap();
  const renderedText = new WeakMap();
  const attrOriginals = new WeakMap();
  const ignored = /^(?:\s*|[0-9.,+\-−×÷*/%^()=√πe!]+|[A-Z]{3}|v?\d+(?:\.\d+)+(?:-[a-z0-9]+)?)$/;
  let active = 'en';
  function localeFor(lang = active) { return ({en:'en-IN',hi:'hi-IN-u-nu-deva',ur:'ur-PK-u-nu-arabext',es:'es-ES',fr:'fr-FR',de:'de-DE',ar:'ar-u-nu-arab',zh:'zh-CN'})[lang] || 'en-IN'; }
  function localizeDigits(value, lang = active) {
    const digits = [...new Intl.NumberFormat(localeFor(lang), {useGrouping:false}).format(9876543210)].reverse();
    return String(value).replace(/[0-9]/g, digit => digits[Number(digit)] || digit);
  }
  function translate(value, lang = active, params = {}) {
    if (lang && typeof lang === 'object') { params = lang; lang = active; }
    const source = String(value ?? '');
    if (!source) return source;
    const trimmed = source.trim();
    if (/^[+-]?(?:\d+|\d{1,3}(?:[, \u00a0]\d{3})+)(?:\.\d+)?$/.test(trimmed)) {
      const locale = localeFor(lang);
      const parts = new Intl.NumberFormat(locale).formatToParts(1234567890123.6);
      const group = parts.find(part => part.type === 'group')?.value || ',';
      const decimal = parts.find(part => part.type === 'decimal')?.value || '.';
      const sign = trimmed.startsWith('-') ? '-' : (trimmed.startsWith('+') ? '+' : '');
      const unsigned = trimmed.replace(/^[+-]/, '').replace(/[, \u00a0\u202f]/g, '');
      const [integer, fraction] = unsigned.split('.');
      const integerParts = parts.filter(part => part.type === 'integer').map(part => part.value);
      const groupSizes = [];
      for (let i = integerParts.length - 1; i > 0; i--) groupSizes.push(integerParts[i].length);
      const primary = groupSizes[0] || 3;
      const secondary = groupSizes[1] || primary;
      let grouped = integer;
      if (integer.length > primary) {
        const chunks = [];
        let end = integer.length;
        let size = primary;
        while (end > 0) { const begin = Math.max(0, end - size); chunks.unshift(integer.slice(begin, end)); end = begin; size = secondary; }
        grouped = chunks.join(group);
      }
      return sign + localizeDigits(grouped, lang) + (fraction !== undefined ? decimal + localizeDigits(fraction, lang) : '');
    }
    const dayCount = trimmed.match(/^(\d+) days? (left|ago)$/);
    if (dayCount) return formatCount(dayCount[2] === 'left' ? 'daysLeft' : 'daysAgo', Number(dayCount[1]), lang);
    const templates = [
      [/^Last checked: (.*?) · Rates last updated: (.*)\. Times are shown in your device's local time\.$/, "Last checked: {checked} · Rates last updated: {updated}. Times are shown in your device's local time."],
      [/^Last checked: (.*?) · Rates last updated: (.*)$/, 'Last checked: {checked} · Rates last updated: {updated}'],
      [/^(\d+) days? (left|ago)$/, 'days {period}'],
      [/^Calculation value: (.+)$/, 'Calculation value: {value}'],
      [/^Calculation result: (.+)$/, 'Calculation result: {value}'],
      [/^Live preview: (.+)$/, 'Live preview: {value}'],
      [/^Memory contains (.+)$/, 'Memory contains {value}'],
      [/^Angle mode (degrees|radians)$/, 'Angle mode {unit}'],
      [/^From currency: ([A-Z]{3})$/, 'From currency: {code}'],
      [/^To currency: ([A-Z]{3})$/, 'To currency: {code}'],
      [/^From unit: (.+)$/, 'From unit: {name}'],
      [/^To unit: (.+)$/, 'To unit: {name}'],
      [/^From: (.+)$/, 'From: {name}'],
      [/^To: (.+)$/, 'To: {name}'],
      [/^Delete (.+)$/, 'Delete {title}'],
      [/^Jump to ([A-Z])$/, 'Jump to {letter}'],
      [/^Every year · (.+)$/, 'Every year · {date}'],
      [/^Reference rates updated · (.+) · unavailable: (.+) \(retry scheduled\)$/, 'Reference rates updated · {source} · unavailable: {missing} (retry scheduled)'],
      [/^Reference rates updated · (.+)$/, 'Reference rates updated · {source}'],
      [/^Selected currency pair not provided by (.+)$/, 'Selected currency pair not provided by {source}'],
      [/^\* 1 ([A-Z]{3}) = Rate unavailable for ([A-Z]{3})$/, '* 1 {from} = Rate unavailable for {to}'],
      [/^\* 1 ([A-Z]{3}) = (.+) ([A-Z]{3}) · rate date (.+)$/, '* 1 {from} = {rate} {to} · rate date {date}'],
      [/^Maximum (\d+) significant digits for accurate results$/, 'Maximum {count} significant digits for accurate results'],
      [/^Maximum (\d+) significant digits per number$/, 'Maximum {count} significant digits per number'],
      [/^Cache cleanup completed with (\d+) verification issue\(s\)$/, 'Cache cleanup completed with {count} verification issue(s)'],
      [/^Maximum (\d+) decimal digits allowed$/, 'Maximum {count} decimal digits allowed'],
      [/^Maximum (\d+) digits allowed$/, 'Maximum {count} digits allowed'],
      [/^Maximum (\d+) subjects allowed$/, 'Maximum {count} subjects allowed'],
      [/^Font scale set to (.+)$/, 'Font scale set to {value}'],
      [/^Max history set to (.+)$/, 'Max history set to {value}'],
      [/^Vibration set to (.+)$/, 'Vibration set to {value}'],
      [/^Default startup screen: (.+)$/, 'Default startup screen: {screen}'],
      [/^Item (.+) \(Lowest unit price\)$/, 'Item {item} (Lowest unit price)'],
      [/^Items (.+) \(Equal lowest unit price\)$/, 'Items {items} (Equal lowest unit price)'],
[/^(\d+) monthly payments · (\d+) interest-only months · Equal principal$/, '{months} monthly payments · {grace} interest-only months · Equal principal'],
      [/^(\d+) monthly payments · (\d+) interest-only months · Equal total payment$/, '{months} monthly payments · {grace} interest-only months · Equal total payment']
    ];
    for (const [pattern, key] of templates) {
      const match = trimmed.match(pattern);
      if (match) {
        let output = dictionaries[lang]?.[key] || source;
        const placeholders = [...key.matchAll(/\{([^}]+)\}/g)].map(item => item[1]);
        const values = match.slice(1);
        placeholders.forEach((placeholder, index) => { const raw = values[index] ?? ''; const preserve = ['checked','updated','name','title','date','source','letter','code','missing','from','to','item','items'].includes(placeholder); const enumValue = (placeholder === 'screen' || placeholder === 'unit' || placeholder === 'value' || placeholder === 'name' || placeholder === 'method') ? (dictionaries[lang]?.[raw] || dictionaries[lang]?.[raw.charAt(0).toUpperCase()+raw.slice(1)]) : null; let numericValue = null; if ((placeholder === 'value' || placeholder === 'rate') && /^[+-]?(?:\d+|\d{1,3}(?:[, ]\d{3})+)(?:\.\d+)?(?:e[+-]?\d+)?$/i.test(raw)) { const parsed = Number(raw.replace(/[, ]/g, '')); if (Number.isFinite(parsed)) { try { numericValue = new Intl.NumberFormat(localeFor(lang), {maximumFractionDigits:12, useGrouping:true}).format(parsed); } catch (_) {} } } const replacement = enumValue || numericValue || (preserve ? raw : localizeDigits(raw, lang)); output = output.replace(`{${placeholder}}`, replacement); });
        return output;
      }
    }
    if (trimmed === 'Memory increased' || trimmed === 'Memory decreased') return dictionaries[lang]?.[trimmed] || source;
    const historyCount = trimmed.match(/^(\d+) unlocked history items? cleared; protected items kept$/);
    if (historyCount) { const n = Number(historyCount[1]); const word = n === 1 ? (lang === 'hi' ? 'प्रविष्टि' : lang === 'ur' ? 'اندراج' : lang === 'es' ? 'elemento' : lang === 'fr' ? 'élément' : lang === 'de' ? 'Eintrag' : lang === 'ar' ? 'عنصر' : '条') : (lang === 'hi' ? 'प्रविष्टियाँ' : lang === 'ur' ? 'اندراجات' : lang === 'es' ? 'elementos' : lang === 'fr' ? 'éléments' : lang === 'de' ? 'Einträge' : lang === 'ar' ? 'عناصر' : '条'); const prefix = lang === 'hi' ? 'अनलॉक इतिहास की' : lang === 'ur' ? 'غیر مقفل ہسٹری کے' : lang === 'es' ? 'Se borraron' : lang === 'fr' ? 'Éléments déverrouillés effacés :' : lang === 'de' ? 'Entsperrte Verlaufseinträge gelöscht:' : lang === 'ar' ? 'تم مسح عناصر السجل غير المقفلة:' : '已清除未锁定历史记录：'; const suffix = lang === 'hi' ? 'हटाईं; सुरक्षित प्रविष्टियाँ रखी गईं' : lang === 'ur' ? 'حذف ہوئے؛ محفوظ اندراجات برقرار' : lang === 'es' ? '; se conservaron los protegidos' : lang === 'fr' ? '; éléments protégés conservés' : lang === 'de' ? '; geschützte Einträge bleiben erhalten' : lang === 'ar' ? '؛ تم الاحتفاظ بالعناصر المحمية' : '；受保护项目已保留'; return `${prefix} ${localizeDigits(n, lang)} ${word} ${suffix}`; }
    if (ignored.test(trimmed)) return source;
    let translated = dictionaries[lang]?.[trimmed] || source;
    if (params && typeof params === 'object') {
      for (const [name, replacement] of Object.entries(params)) translated = translated.replaceAll(`{${name}}`, String(replacement));
    }
    return translated;
  }
  function applyTextNode(node) {
    const current = node.nodeValue ?? '';
    // A mutation equal to our last output is our own observer notification.
    // Any other value is a genuine application update and becomes the new source.
    if (!originals.has(node) || (renderedText.has(node) && current !== renderedText.get(node))) {
      originals.set(node, current);
    }
    const source = originals.get(node);
    if (!source || !source.trim()) return;
    const leading = source.match(/^\s*/)?.[0] || '';
    const trailing = source.match(/\s*$/)?.[0] || '';
    const core = source.trim();
    const output = leading + translate(core) + trailing;
    if (current !== output) node.nodeValue = output;
    renderedText.set(node, output);
  }
  function applyElement(el) {
    if (!(el instanceof Element)) return;
    const isTextControl = el.matches('input,textarea');
    if (el.matches('textarea,input[type=search],input[type=text],input:not([type])')) el.setAttribute('dir', 'auto');
    else if (el.matches('input[type=number],input[type=tel],input[inputmode=numeric],input[inputmode=decimal],.calc-expression,.calc-result')) el.setAttribute('dir', 'ltr');
    if (!el.matches('script,style,code,[contenteditable="true"]') && !isTextControl) {
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode(node) { return node.parentElement?.closest('option,input,textarea,script,style,code,[contenteditable=\"true\"]') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
      const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
      nodes.forEach(applyTextNode);
    }
    // Attributes are translated even on input/textarea elements; only their
    // editable value is intentionally left untouched.
    ['aria-label','title','placeholder'].forEach(attr => {
      if (!el.hasAttribute(attr)) return;
      if (!attrOriginals.has(el)) attrOriginals.set(el, {});
      const saved = attrOriginals.get(el);
      const current = el.getAttribute(attr);
      if (!saved[attr] || (saved[attr].rendered !== undefined && current !== saved[attr].rendered)) {
        saved[attr] = { source: current, rendered: undefined };
      }
      const output = translate(saved[attr].source);
      if (current !== output) el.setAttribute(attr, output);
      saved[attr].rendered = output;
    });
  }
  function apply(lang) {
    active = dictionaries[lang] ? lang : 'en';
    document.documentElement.lang = active;
    document.documentElement.dir = ['ar','ur'].includes(active) ? 'rtl' : 'ltr';
    document.documentElement.dataset.locale = active;
    applyElement(document.body);
    document.querySelectorAll('option').forEach(option => {
      if (!originals.has(option.firstChild) && option.firstChild?.nodeType === Node.TEXT_NODE) originals.set(option.firstChild, option.firstChild.nodeValue);
      if (option.firstChild?.nodeType === Node.TEXT_NODE) applyTextNode(option.firstChild);
      applyElement(option);
    });
    document.querySelectorAll('[aria-label],[title],[placeholder]').forEach(applyElement);
    // Localize keypad glyphs without changing data-popup, which remains canonical ASCII for parsing.
    const locale = localeFor(active);
    const nativeDigits = new Intl.NumberFormat(locale, {useGrouping:false}).format(9876543210);
    const digitGlyphs = [...nativeDigits].reverse();
    const mapDigits = value => String(value).replace(/[0-9]/g, digit => digitGlyphs[Number(digit)] || digit);
    document.querySelectorAll('.key-btn[data-popup]').forEach(button => {
      const key = button.getAttribute('data-popup');
      if (/^\d+$/.test(key)) button.textContent = mapDigits(key);
      else if (key === '.') button.textContent = new Intl.NumberFormat(locale).formatToParts(1.1).find(part => part.type === 'decimal')?.value || '.';
    });
  }
  function localizeNumber(value, options = {}) {
    const locale = localeFor(active);
    try { return new Intl.NumberFormat(locale, options).format(value); }
    catch (_) { return String(value); }
  }
  const countMessages = {
    daysLeft: {
      en: {one:'{n} day left',other:'{n} days left'}, hi:{one:'{n} दिन शेष',other:'{n} दिन शेष'}, ur:{one:'{n} دن باقی',other:'{n} دن باقی'},
      es:{one:'Queda {n} día',other:'Quedan {n} días'}, fr:{one:'Il reste {n} jour',other:'Il reste {n} jours'}, de:{one:'Noch {n} Tag',other:'Noch {n} Tage'},
      ar:{zero:'لا أيام متبقية',one:'بقي يوم واحد',two:'بقي يومان',few:'بقيت {n} أيام',many:'بقي {n} يومًا',other:'بقي {n} يوم'}, zh:{other:'还剩 {n} 天'}
    },
    daysAgo: {
      en:{one:'{n} day ago',other:'{n} days ago'}, hi:{one:'{n} दिन पहले',other:'{n} दिन पहले'}, ur:{one:'{n} دن پہلے',other:'{n} دن پہلے'},
      es:{one:'Hace {n} día',other:'Hace {n} días'}, fr:{one:'Il y a {n} jour',other:'Il y a {n} jours'}, de:{one:'Vor {n} Tag',other:'Vor {n} Tagen'},
      ar:{zero:'منذ صفر يوم',one:'منذ يوم واحد',two:'منذ يومين',few:'منذ {n} أيام',many:'منذ {n} يومًا',other:'منذ {n} يوم'}, zh:{other:'{n} 天前'}
    }
  };
  function formatCount(key, count, lang = active) {
    const n = Math.abs(Number(count));
    if (!Number.isFinite(n)) return '';
    const locale = localeFor(lang);
    let category = 'other';
    try { category = new Intl.PluralRules(locale).select(n); } catch (_) { category = n === 1 ? 'one' : 'other'; }
    const forms = countMessages[key]?.[lang] || countMessages[key]?.en;
    const template = forms?.[category] || forms?.other || '{n}';
    let numberText = String(n);
    try { numberText = new Intl.NumberFormat(locale).format(n); } catch (_) {}
    return template.replace('{n}', numberText);
  }
  window.SALocalization = { apply, translate, hasTranslation: (value, lang = active) => typeof dictionaries[lang]?.[String(value ?? '').trim()] === 'string' && dictionaries[lang][String(value ?? '').trim()].length > 0, catalogueKeys: Object.keys(rows), localizeNumber, localizeDigits, formatCount, get locale(){ return localeFor(active); }, get language(){ return active; }, supported: ['en', ...langs] };
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'characterData') applyTextNode(record.target);
        else record.addedNodes.forEach(node => {
          if (node.nodeType === Node.TEXT_NODE) applyTextNode(node);
          else if (node.nodeType === Node.ELEMENT_NODE) {
            applyElement(node);
            node.querySelectorAll?.('[aria-label],[title],[placeholder],option').forEach(applyElement);
          }
        });
      }
    });
    const start = () => { if (document.body) observer.observe(document.body, {subtree:true, childList:true, characterData:true}); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
  }
})();
