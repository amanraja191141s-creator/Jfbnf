# SA Calculator v98.89 — Build Verification

- Release: `1.99.03-v98.89`
- Android versionCode: `1099109`
- Cache namespace: `sa-calculator-v98-89-gst-row-placeholder-caret-v9889`

## Local checks
- `npm test`: 133 passed, 0 failed.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- `node --check assets/js/theme-bootstrap.js`: passed.
- `node --check service-worker.js`: passed.
- `node scripts/prepare-android-web.mjs`: passed; 13 required assets verified.
- Root and `www/` copies: 8/8 byte-identical.
- Workflow YAML: 12 copies parsed and byte-identical.
- Release test entry points: 24/24 exist.
- ZIP archive: `unzip -t` passed.

## Not run
- GitHub Actions remote workflow.
- Android Gradle/APK build.
- Physical Android WebView/device interaction and performance test.
- Browser screenshot automation was attempted, but navigation was blocked by the execution environment's browser policy; visual verification therefore remains a device/CI task.
