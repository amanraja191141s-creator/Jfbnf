# SA Calculator v98.81 — Action-Time GST + Unit Audit

## Source basis
The supplied 720×1560 action-time recording `Screenrecording_20261123_194055.mp4` was inspected frame-by-frame at representative interaction points.

### GST behavior observed
- Original Amount begins empty with `Enter amount` placeholder and a visible text cursor.
- Amount entry is grouped with the configured thousands separator (reference example: `653,355,666`).
- GST amount input is capped at the reference nine-digit ceiling; the supplied recording shows the exact overflow feedback `Amount cannot exceed 99,99,99,999`.
- GST rate begins empty (`Add rate`) and quick-rate buttons expose 5% and 18%.
- With GST / Without GST are mutually exclusive modes.
- Same State / Different State are mutually exclusive place-of-supply modes.
- `=` is the calculation/commit action; the visible Calculate button remains hidden.
- Same State result contains GST Amount, SGST, CGST and Gross Amount.
- Different State result contains GST Amount, IGST and Gross Amount.
- After a result has been committed, changing mode/rate/place recalculates the existing result instead of blanking the result surface.
- Editing the actual numeric amount still invalidates the committed result until the next `=` action.

## Unit Converter action-time fix
- Each From/To card now has exactly one visible unit selector.
- The redundant static unit-code display was removed; the enhanced picker trigger is the single visible selector.
- Swap remains the tall coral keypad action for Unit Converter.
- Existing category/default mappings and conversion math remain unchanged.

## CI / release hardening
- Runtime, PWA, service worker, standalone Android workflow and repository workflow use release `1.98.95-v98.81`.
- Android versionCode is `1099101`.
- The new GST/Unit regression entry point is included in both workflow verification lists and the npm release test script.
- Root and `www/` web assets are rebuilt and synchronized.
